<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Wildlife & Interior Design Website</title>
    <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  
</head>
<style>
    :root {
    font-size: 16px;
}

body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    margin: 0;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Banner Section */
.banner {
    position: relative;
    width: 100%;
    height: 80vh;
    background: url('https://media.geeksforgeeks.org/wp-content/uploads/20230802132058/Wildlife-Sanctuary.webp') 
        no-repeat center center;
    background-size: cover;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    color: white;
    padding: 20px;
}

.banner-content {
    background: rgba(0, 0, 0, 0.5);
    padding: 20px;
    border-radius: 10px;
    width: 60%;
    max-width: 800px;
}

.banner h1 {
    font-size: 3.5rem;
    font-weight: bold;
}

.banner p {
    font-size: 1.2rem;
    margin-top: 15px;
    line-height: 1.6;
}

/* Content Wrapper */
.content-wrapper {
    display: flex;
    flex-wrap: wrap;
    width: 100%;
    max-width: 1600px;
    background: white;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
    margin: 50px auto;
    padding: 20px;
}

/* Sidebar */
.sidebar {
    background-color: rgba(94, 56, 117, 0.8);
    color: white;
    padding: 20px;
    flex: 1;
    min-width: 250px;
}

.sidebar h2,
.sidebar h3 {
    color: #fff;
    border-bottom: 2px solid white;
    padding-bottom: 10px;
}

.sidebar ul {
    list-style: none;
    padding: 0;
}

.sidebar ul li {
    padding: 8px 0;
}

.sidebar ul li a {
    color: #f8f8f8;
    text-decoration: none;
}

.sidebar ul li a:hover {
    text-decoration: underline;
}

/* Main Content */
.main-content {
    background: rgb(232, 195, 195);
    flex: 2;
    padding: 30px;
    text-align: center;
}

.main-content h2 {
    color: #2d5f2d;
    border-bottom: 2px solid #4caf50;
    padding-bottom: 10px;
}

/* Contact Form */
.form-container {
    display: flex;
    justify-content: center;
    padding: 40px 20px;
}

.contact-form {
    background: #f9f9f9;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 600px;
}

.contact-form h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 2rem;
}

.contact-form label {
    display: block;
    margin-bottom: 10px;
    font-weight: bold;
    text-align: left;
}

.contact-form input,
.contact-form textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 1rem;
}

.contact-form button {
    display: block;
    width: 100%;
    padding: 12px;
    background: rgb(255, 0, 0);
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 1rem;
    font-weight: bold;
    cursor: pointer;
    transition: background 0.3s ease;
}

.contact-form button:hover {
    background: darkred;
}

/* RESPONSIVE DESIGN */
@media screen and (max-width: 1024px) {
    .banner h1 {
        font-size: 3rem;
    }
    .banner-content {
        width: 75%;
    }
    .content-wrapper {
        flex-direction: column;
        align-items: center;
    }
    .contact-form {
        width: 75%;
    }
}

@media screen and (max-width: 768px) {
    .banner {
        height: 60vh;
    }
    .banner h1 {
        font-size: 2.5rem;
    }
    .banner-content {
        width: 85%;
    }
    .sidebar {
        text-align: center;
    }
    .contact-form {
        width: 85%;
    }
}

@media screen and (max-width: 480px) {
    .banner {
        height: 50vh;
        padding: 10px;
    }
    .banner h1 {
        font-size: 2rem;
    }
    .banner-content {
        width: 90%;
        padding: 15px;
    }
    .sidebar {
        min-width: 100%;
        text-align: center;
    }
    .form-container {
        padding: 20px;
    }
    .contact-form {
        width: 95%;
    }
}

</style>
<body>
    <?php include 'h.php'; ?>

    <div class="banner">
        <div class="banner-content">
            <h1>Contact Us</h1>

        </div>
    </div>
    <div class="content-wrapper">
        <!-- Left Sidebar -->
        <div class="sidebar">
            <h2>Latest Articles</h2>
            <ul>
                <li><a href="#">Wildlife Conservation Efforts</a></li>
                <li><a href="#">Top Wildlife Sanctuaries to Visit</a></li>
                <li><a href="#">How to Volunteer for Wildlife Projects</a></li>
                <li><a href="#">Protecting Endangered Species</a></li>
            </ul>
        </div>

        <!-- Main Content with Grid Services -->
        <div class="main-content">


            <div class="form-container">
                <form class="contact-form">
                    <h2>Get in Touch</h2>
                    <label for="name">Name</label>
                    <input type="text" id="name" name="name" required>

                    <label for="company">Company</label>
                    <input type="text" id="company" name="company">

                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>

                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" required>

                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="5" required></textarea>

                    <button type="submit">Submit</button>
                </form>
            </div>
        </div>

        <!-- Right Sidebar -->
        <div class="sidebar">
            <h2>Contact Us</h2>
            <p style="padding-top: 20px;">Email: info@wildlifesanctuary.com</p>
            <p>Phone: +123 456 7890</p>
            <p>Address: 123 Wildlife Lane, Nature City</p>

          
        </div>
    </div>


    <?php include 'f.php'; ?>
</body>

</html>