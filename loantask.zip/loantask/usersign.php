<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    
    if (empty($email) || empty($password)) {
        echo "<script type='text/javascript'>alert('Please enter both email and password');</script>";
    } else {
        
        $stmt = $conn->prepare("SELECT * FROM farmers WHERE email = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $user_data = $result->fetch_assoc();

                
                if (password_verify($password, $user_data['password'])) {
                    
                   
                    $_SESSION['full_name'] = $user_data['fullname']; 
                    $_SESSION['email'] = $user_data['email']; 
                    $_SESSION['id'] = $user_data['id'];
                    header("Location: homepagem.php"); 
                    exit();
                } else {
                    echo "<script type='text/javascript'>alert('Wrong password');</script>";
                }
            } else {
                echo "<script type='text/javascript'>alert('User not found');</script>";
            }
        } else {
            echo "<script type='text/javascript'>alert('Database query failed');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-UsersSign</title>
  
    <link rel="stylesheet" href="usersign.css">

    
</head>
<style>
 
    
</style>
<body>
    <script src="usersign.js"></script>
    <div> 
    <?php
       include 'h.php';
       ?>

<div class="mainbody">
        <div class="mainbody1">    
        <h2><u>Register / User Login Form. </u></h2>
        <div class="signin-section ptb-100">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                    <form class="signin-form" method="POST" onsubmit="return validateLogin()">
                        <div class="form-group">
                            <label>Enter Email</label>
                            <input type="email" id="email" name="email" class="form-control"
                                placeholder="Enter Your Email" >
                        </div>
                        <div class="form-group">
                            <label>Enter Password</label>
                            <input type="password" id="password" name="password" class="form-control"
                                placeholder="Enter Your Password" >
                        </div>
                        <div class="create-btn">
                            <p>
                                <a href="forgot-password">
                                    Forgot Password
                                    <i class="bx bx-chevrons-right bx-fade-right"></i>
                                </a>
                            </p>
                        </div>
                        <div class="signin-btn text-center">
                            <button type="submit" name="signin">Sign In</button>
                           

                        </div>
                        <div class="other-signin text-center">
                            <span>Or sign in with</span>
                           
                        </div>
                        <div class="create-btn text-center">
                            <p>Not have an account?
                                <a href="userregistration.php">
                                    Create an account
                                    <i class="bx bx-chevrons-right bx-fade-right"></i>
                                </a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


        
</div>

      
        </div>
    
      
    </div>
         
   



<script>
    (function(d, w, c) {
        w.ChatraID = 'Z3tkRZ7XYPdwa8643';
        var s = d.createElement('script');
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        s.async = true;
        s.src = 'https://call.chatra.io/chatra.js';
        if (d.head) d.head.appendChild(s);
    })(document, window, 'Chatra');
</script>

<script>
  const scrollToTopBtn = document.getElementById('scrollToTopBtn');

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    scrollToTopBtn.style.display = 'block'; 
  } else {
    scrollToTopBtn.style.display = 'none'; 
  }
});


scrollToTopBtn.addEventListener('click', (e) => {
  e.preventDefault();
  window.scrollTo({
    top: 0,
    behavior: 'smooth' 
  });
});
</script>
</body>
</html>