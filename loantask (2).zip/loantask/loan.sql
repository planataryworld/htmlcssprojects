-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2025 at 03:54 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(254) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Password` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `Password`) VALUES
(1, 'harsha', 'harsha@gmail.com', 'Manoj@131');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(254) NOT NULL,
  `name` varchar(254) NOT NULL,
  `phonenumber` varchar(11) NOT NULL,
  `email` varchar(254) NOT NULL,
  `subject` varchar(254) NOT NULL,
  `message` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `phonenumber`, `email`, `subject`, `message`) VALUES
(2, 'Manoj', '2147483647', 'mcreddi55@gmail.com', 'need to buy a product', 'test ticket');

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `id` int(254) UNSIGNED NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `security_question` varchar(50) NOT NULL,
  `answer` varchar(100) NOT NULL,
  `farmsize` varchar(50) NOT NULL,
  `crops` varchar(50) NOT NULL,
  `bank_account` varchar(50) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`id`, `fullname`, `dob`, `gender`, `address`, `city`, `email`, `mobile`, `password`, `security_question`, `answer`, `farmsize`, `crops`, `bank_account`, `reg_date`) VALUES
(1, 'manoj', '1995-02-16', 'male', 'kurnool', 'kurnool', 'mcreddi55@gmail.com', '9505771512', '$2y$10$KsqzzQ5RU2w.QdCW0OxNsuBX02h4aAVlOcll.OTWPi57m72/zbSlW', 'favourite-color', 'white', '10acers', 'wheat', '216158466286', '2025-01-30 08:33:54'),
(2, 'vinay', '1995-01-16', 'male', 'hyderabad', 'hyderabad', 'vinay@gmail.com', '9000312466', '$2y$10$tU22ZEBVMn.vJG8D4AHRr.yF0WkNrSi.vrmrrT2lIAtU5wSv82imy', 'favourite-color', 'white', '5acers', 'wheat', '2161584362840', '2025-01-31 08:28:22');

-- --------------------------------------------------------

--
-- Table structure for table `loanapplication`
--

CREATE TABLE `loanapplication` (
  `loanpurpose` varchar(254) NOT NULL,
  `id` int(254) NOT NULL,
  `purpose_of_loan` varchar(254) NOT NULL,
  `loan_amount` varchar(254) NOT NULL,
  `approved_loan_amount` varchar(254) NOT NULL,
  `interestrate` varchar(254) NOT NULL,
  `repayment_period` varchar(254) NOT NULL,
  `location` varchar(254) NOT NULL,
  `fullname` varchar(254) NOT NULL,
  `postaladdress` varchar(255) NOT NULL,
  `physicaladdress` varchar(254) NOT NULL,
  `telephone` varchar(254) NOT NULL,
  `email` varchar(254) NOT NULL,
  `document` varchar(254) NOT NULL,
  `status` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loanapplication`
--

INSERT INTO `loanapplication` (`loanpurpose`, `id`, `purpose_of_loan`, `loan_amount`, `approved_loan_amount`, `interestrate`, `repayment_period`, `location`, `fullname`, `postaladdress`, `physicaladdress`, `telephone`, `email`, `document`, `status`) VALUES
('croploan', 9, 'kisan-credit-card-scheme', '30,000-50,000', '37450', '7.0', '6months', '', 'manoj', 'kurnool', 'kurnool', '9000312466', 'mcreddi55@gmail.com', 'Inter memo.pdf', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `loantypes`
--

CREATE TABLE `loantypes` (
  `id` int(254) NOT NULL,
  `schemes` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `period` varchar(254) NOT NULL,
  `interestrate` varchar(254) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loantypes`
--

INSERT INTO `loantypes` (`id`, `schemes`, `amount`, `period`, `interestrate`) VALUES
(1, 'kisan-credit-card-scheme', '30,000-50,000', '6months', '7.0'),
(2, 'krishi-mitra-card-scheme', '51,000-1,00,000', '14months', '7.5'),
(3, 'farm-machinery-loans', '1,50,000-3,00,00Lakhs', '24months', '8.5'),
(4, 'Dairy-Loans', '3,50,000-7,00,00Lakhs', '36months', '11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loanapplication`
--
ALTER TABLE `loanapplication`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `loantypes`
--
ALTER TABLE `loantypes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(254) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(254) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `id` int(254) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `loanapplication`
--
ALTER TABLE `loanapplication`
  MODIFY `id` int(254) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `loantypes`
--
ALTER TABLE `loantypes`
  MODIFY `id` int(254) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
