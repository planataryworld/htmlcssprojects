

<?php
session_start();
include 'connection.php'; // Include your database connection file

// Query to fetch user data
$sql = "SELECT id,  name, gender, email,  mobile FROM users;";
$result = $conn->query($sql);

if (!isset($_SESSION['email'])) {  // If session is not set , it redirects to adminlogin page.
    header("Location:index.php");
    exit();
}

$user_Id = $_SESSION['email'];

$sqlQuery = "SELECT * FROM admindata WHERE email='$user_Id'";
$getResult = mysqli_query($conn, $sqlQuery);

if (!$getResult) {
    echo "<script>alert('Error fetching user data.');</script>";
    exit();
    }

$rowData = mysqli_fetch_assoc($getResult);
$storedDataName = $rowData['name'];
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(192, 187, 187); 
        }

        .container {
            /* display: flex;
            justify-content: space-between;
            align-items: center; */
            padding: 20px;
            /* border: 1px solid red; */
           
        }

        
        .description {
            flex: 1;
            /* border: 1px solid red; */
           
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
             /* margin-bottom: 300px;  */
            margin-left: 300px;
           
        }

       
        .toolbar {
            display: flex;
            width: 47%;
            justify-content: end;
            align-items: flex-end;
            flex-direction: row;
            align-items: center;
            gap: 45px;
            padding: 10px;
            background-color: rgb(192, 187, 187);
            border-radius: 8px;
            /* border: 1px solid red; */
            margin-top: 20px;
            margin-left: 1050px;
            
            /* box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); */
            /* margin-bottom: 250px; */
        }

        
        .sort {
            display: flex;
            align-items: center;
            color: #333;
            cursor: pointer;
        }

        .filter-icon {
            font-size: 18px;
            margin-right: 4px;
        }

        
        .search-container {
            flex-grow: 1;
            display: flex;
        }

        .search-bar {
            width: 250px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
        }

        .search-bar::placeholder {
            color: #aaa;
        }

        
        .cancel {
            color: #e74c3c;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
           padding: 8px;
        }

        
        .add-product {
            background-color: #e74c3c;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
            width: 50vw;
            height: 5vh;
        }

        .add-product:hover {
            background-color: #c0392b;
        }
       
        /* Container for the table */
.student-database-container {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    margin: 20px auto;
    width: 75%;
    background-color: #f9f9f9;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 10px;
    margin-left: 340px;
}

/* Header for the table */
.student-database-container h3 {
    color: #5B3D7F;
    text-align: center;
    font-size: 22px;
    margin-bottom: 10px;
}

/* Table styles */
.student-database-container table {
    width: 100%;
    border-collapse: collapse;
    background-color: #ffffff;
}

.student-database-container th {
    text-align: left;
    font-weight: bold;
    color: #ff5252; /* Red header color */
    padding: 10px;
    border-bottom: 2px solid #e0e0e0;
    font-size: 16px;
    text-transform: lowercase;
}

.student-database-container td {
    color: #333;
    padding: 10px;
    border-bottom: 1px solid #e0e0e0;
    font-size: 14px;
    text-align: left;
}

.student-database-container tr:nth-child(even) {
    background-color: #f5f5f5; /* Alternate row background */
}

.student-database-container tr:last-child td {
    border-bottom: none; /* Remove bottom border for last row */
}

.student-database-container td[colspan="5"] {
    text-align: center;
    font-weight: bold;
    color: #ff5252;
}

    </style>

     <?php
    include 'adminusers.php';
    ?> 
</head>
<body>
    <!-- Container for description and toolbar -->
    <div class="container">
        <!-- Description Section -->
        <div class="description">
           
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
                // Display a welcome message if the user is logged in
                if (isset($_SESSION['email'])) {
                     echo "<span class='username'> " . htmlspecialchars($storedDataName) . "</span>";
                }
                ?>!</p>
                 <p>Check all your orders details here</p>
        </div>
        
        <!-- Toolbar Section -->
        <div class="toolbar">
            <!-- Sort Button -->
            <div class="sort">
            <i class="fa-solid fa-filter"></i>&nbsp;&nbsp;
                <span>Sort</span>
            </div>

            <!-- Search Bar -->
            <div class="search-container">
                <input type="text" class="search-bar" placeholder="Search">&nbsp;&nbsp;&nbsp;
                <span class="cancel">Cancel</span>
            </div>
            
        
        </div>
    </div>

    <div class="student-database-container">
    <h3>User Information</h3>
    <table>
        <thead>
            <tr>
                <th>id</th>
                <th>username</th>
                <th>gender</th>
                <th>email</th>
                <th>phoneNumber</th>
            </tr>
        </thead>
        <tbody>
          
             <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?> 
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['gender']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['mobile']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No records found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>