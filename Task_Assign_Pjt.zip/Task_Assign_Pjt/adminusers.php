<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <style>
    body {
        margin: 0;
        padding: 0;
        box-sizing: border-box; 
            overflow-x: hidden; 
    }
    .pro {
        font-size: 28px;
        display: block;
        background-color:#ff4d4d;
        height: 8vh;
        margin: 0;
        padding: 0;
        width: 100%;
    }

    .pro h3 {
        margin: 0;
        padding: 0;
        padding-left: 320px;
        padding-top: 10px;
    }
   </style>
</head>
<?php
    include 'sidenav.php';
?>
<body>
    <div class="pro">
        <h3>Users</h3>
    </div>
    
</body>
</html>