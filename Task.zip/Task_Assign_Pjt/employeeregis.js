
        function validateForm() {
            // debugger;
            var firstName = document.userregis.first_name.value.trim();
            var lastName = document.userregis.last_name.value.trim();
            var phone = document.userregis.phone.value.trim();
            var domain = document.userregis.domain.value.trim();
            var email = document.userregis.email.value.trim();
            var password = document.userregis.password.value.trim();
            var skills = document.userregis.skills.value.trim();

            // First Name Validation
            if (firstName === "" || firstName === null) {
                alert("First name should not be empty.");
                return false;
            }

            if (/^\s|\s$/.test(firstName)) {
                alert("First name should not start or end with spaces.");
                return false;
            }

            if (!/^[a-zA-Z]+$/.test(firstName)) {
                alert("First name can only contain letters with no spaces.");
                return false;
            }

            if (firstName.length < 3 || firstName.length > 20) {
                alert("First name should be between 3 and 20 characters.");
                return false;
            }

            // Last Name Validation
            if (lastName === "" || lastName === null) {
                alert("Last name should not be empty.");
                return false;
            }

            if (/^\s|\s$/.test(lastName)) {
                alert("Last name should not start or end with spaces.");
                return false;
            }

            if (!/^[a-zA-Z]+$/.test(lastName)) {
                alert("Last name can only contain letters with no spaces.");
                return false;
            }

            if (lastName.length < 3 || lastName.length > 20) {
                alert("Last name should be between 3 and 20 characters.");
                return false;
            }

            if (firstName === lastName) {
                alert("First name and last name should not be the same.");
                return false;
            }

            // Phone Number Validation
            // Phone number validation
            if (phone === "") {
                alert("Please enter your phone number.");
                return false;
            }

            if (!/^[6-9][0-9]{9}$/.test(phone)) {
                alert("Please enter a valid 10-digit mobile number starting with a digit between 6 and 9.");
                return false;
            }

            // Domain Validation
            if (domain === "") {
                alert("Please select a valid domain.");
                return false;
            }

            // Email Validation
            if (email === "" || email === null) {
                alert("Please enter an email address.");
                return false;
            }

            if (/^\s|\s$/.test(email)) {
                alert("Email should not start or end with spaces.");
                return false;
            }

            if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z]+\.(com)$/.test(email)) {
                alert("Please enter a valid email address with a '.com' domain.");
                return false;
            }

            // Password Validation
            if (password === "") {
                alert("Password should not be empty.");
                return false;
            }

            if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(password)) {
                alert(
                    "Password must be at least 8 characters long, include one uppercase letter, one lowercase letter, one number, and one special character."
                );
                return false;
            }

            // Skills Validation
            if (skills === "") {
                alert("Skills should not be empty.");
                return false;
            }

            if (/^\s|\s$/.test(skills)) {
                alert("Skills should not start or end with spaces.");
                return false;
            }

            alert("Thanks for Registration.");
            return true;
        }
    