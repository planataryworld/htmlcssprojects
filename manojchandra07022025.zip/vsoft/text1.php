<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Wildlife & Interior Design Website</title>
  <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    :root {
      font-size: 16px;
    }

    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      margin: 0;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .banner {
      position: relative;
      width: 100%;
      height: 100vh;
      background: url('https://media.geeksforgeeks.org/wp-content/uploads/20230802132058/Wildlife-Sanctuary.webp') no-repeat center center;
      background-size: cover;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: white;
      padding: 20px;
    }

    .banner-content {
      background: rgba(0, 0, 0, 0.2);
      padding: 20px;
      border-radius: 10px;
      width: 60%;
    }

    .banner h1 {
      font-size: 3.5rem;
      font-weight: bold;
    }

    .banner p {
      font-size: 1.2rem;
      margin-top: 15px;
      line-height: 1.6;
    }

    .cta-btn {
      display: inline-block;
      margin-top: 30px;
      padding: 12px 24px;
      background: rgb(255, 0, 0);
      color: white;
      text-decoration: none;
      border-radius: 30px;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .cta-btn:hover {
      background: darkred;
    }

    .card-container {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
      padding: 40px 20px;
    }

    .card {
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      padding: 15px;
      text-align: center;
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: scale(1.05);
    }

    .card img {
      max-width: 100%;
      border-radius: 10px;
    }

    .card h1 {
      font-size: 1.2rem;
      margin: 10px 0;
    }

    .card p {
      font-size: 0.9rem;
      text-align: justify;
      padding: 10px;
    }

    /* Responsive Design */
    @media screen and (max-width: 1024px) {
      .banner h1 {
        font-size: 3rem;
      }

      .banner-content {
        width: 75%;
      }

      .card-container {
        grid-template-columns: 1fr;
      }
    }

    @media screen and (max-width: 768px) {
      .banner h1 {
        font-size: 2.5rem;
      }

      .banner-content {
        width: 85%;
      }

      .card-container {
        grid-template-columns: 1fr;
      }
    }

    @media screen and (max-width: 480px) {
      .banner h1 {
        font-size: 2rem;
      }

      .banner-content {
        width: 90%;
      }

      .card-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <?php include 'h.php'; ?>

  <div class="banner">
    <div class="banner-content">
      <h1>Services</h1>
      <p>We follow a comprehensive approach to saving India’s wildlife. As we continue to develop and improve our rescue and medical resources, our Elephant Hospital and conservation and care centres, our research and partnerships, and our talented and dedicated staff, we take a holistic view of saving both individual animals, as well as protecting an entire species.</p>
      <a href="#" class="cta-btn">Explore More</a>
    </div>
  </div>

  <div class="card-container">
    <div class="card">
      <img src="https://cms.tgtdc.in/fetch?payload=6ef26d1f-3b07-49a8-bb2b-ec3c121a325b.jpg" alt="Card Image 1">
      <h1>Hyderabad's Hidden Wildlife</h1>
      <p>This sanctuary is home to a variety of flora and fauna, making it a perfect getaway for nature enthusiasts.</p>
    </div>
    <div class="card">
      <img src="https://cms.tgtdc.in/fetch?payload=1bef4299-146c-4cd9-aa78-17b96782d42e.jpg" alt="Card Image 2">
      <h1>Kinnerasani Sanctuary</h1>
      <p>This exotic wildlife sanctuary is the natural habitat of some exotic wildlife and features guided tours.</p>
    </div>
    <div class="card">
      <img src="https://cms.tgtdc.in/fetch?payload=ec91957d-2ad7-4036-aca0-53ab6a5bdfe9.jpg" alt="Card Image 3">
      <h1>Deccan's Natural Beauty</h1>
      <p>Foxes, black-naped hares, wild boars, and Indian vipers await nature lovers in this sanctuary.</p>
    </div>
    <div class="card">
      <img src="https://wildlifesos.org/wp-content/uploads/cache/2020/09/Flapshell-turtles-Shresatha/948053050.jpg" alt="Card Image 4">
      <h1>Deccan's Natural Beauty</h1>
      <p>Foxes, black-naped hares, wild boars, and Indian vipers await nature lovers in this sanctuary.</p>
    </div>
  </div>

  <?php include 'f.php'; ?>
</body>
</html>