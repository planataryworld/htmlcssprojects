<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['loan_purpose'])) {
    $loan_purpose = $_POST['loan_purpose'];

    $stmt = $conn->prepare("SELECT amount, period, interestrate FROM loantypes WHERE schemes = ?");
    $stmt->bind_param("s", $loan_purpose);
    $stmt->execute();
    $stmt->bind_result($loan_amount, $repayment_period, $interest_rate);
    $stmt->fetch();
    
    echo json_encode(["loan_amount" => $loan_amount, "repayment_period" => $repayment_period, "interest_rate" => $interest_rate]);

    $stmt->close();
}

$conn->close();
?>



