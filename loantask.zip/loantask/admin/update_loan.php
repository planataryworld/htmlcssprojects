<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $approved_loan_amount = $_POST['approved_loan_amount'];
    $status = $_POST['status'];

    $query = "UPDATE loanapplication SET approved_loan_amount = ?, status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("dsi", $approved_loan_amount, $status, $id);
    
    if ($stmt->execute()) {
        echo "Success";
    } else {
        echo "Error: " . $conn->error;
    }
    $stmt->close();
    $conn->close();
}
?>
