<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Wildlife & Interior Design Website</title>
  <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    :root {
      font-size: 16px;
    }

    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      margin: 0;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .banner {
      position: relative;
      width: 100%;
      height: 100vh;
      background: url('https://media.geeksforgeeks.org/wp-content/uploads/20230802132058/Wildlife-Sanctuary.webp') no-repeat center center;
      background-size: cover;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: white;
      padding: 20px;
    }

    .banner-content {
      background: rgba(0, 0, 0, 0.2);
      padding: 20px;
      border-radius: 10px;
      width: 60%;
    }

    .banner h1 {
      font-size: 3.5rem;
      font-weight: bold;
    }

    .banner p {
      font-size: 1.2rem;
      margin-top: 15px;
      line-height: 1.6;
    }

    .cta-btn {
      display: inline-block;
      margin-top: 30px;
      padding: 12px 24px;
      background: rgb(255, 0, 0);
      color: white;
      text-decoration: none;
      border-radius: 30px;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .cta-btn:hover {
      background: darkred;
    }

    .card-container {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 25px;
      padding: 20px;
    }

    .card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 10px;
    }

    .testimonials-section {
      text-align: center;
      padding: 40px 20px;
      background: #f9f9f9;
    }

    .testimonials-section h2 {
      font-size: 2rem;
      margin-bottom: 20px;
    }

    .testimonials-container {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      padding: 20px;
    }

    .testimonial-card {
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      transition: transform 0.3s ease;
    }

    .testimonial-card:hover {
      transform: scale(1.05);
    }

    .testimonial-card p {
      font-size: 1rem;
      font-style: italic;
      color: #555;
    }

    .testimonial-card h3 {
      font-size: 1.1rem;
      margin-top: 10px;
      color: #333;
    }

    @media screen and (max-width: 1024px) {
      .testimonials-container, .card-container {
        grid-template-columns: repeat(2, 1fr);
      }
    }

    @media screen and (max-width: 768px) {
      .testimonials-container, .card-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <?php include 'h.php'; ?>

  <div class="banner">
    <div class="banner-content">
      <h1>Gallery</h1>
      <p> We showcase the beauty and diversity of India's wildlife through our comprehensive gallery...</p>
      <a href="#" class="cta-btn">Explore More</a>
    </div>
  </div>

  <div class="card-container">
    <div class="card">
      <img src="https://wildlifesos.org/wp-content/uploads/cache/2020/09/nisha-Akash/970228889.jpg" alt="Card Image 1">
    </div>
    <div class="card">
      <img src="https://wildlifesos.org/wp-content/uploads/2020/09/jaya21-Akash.jpg" alt="Card Image 2">
    </div>
    <div class="card">
      <img src="https://wildlifesos.org/wp-content/uploads/cache/2020/09/rescued-rusty-spotted-cat-Akash/2775532294.jpg" alt="Card Image 3">
    </div>
    <div class="card">
      <img src="https://wildlifesos.org/wp-content/uploads/cache/2020/09/Gail-Shresatha/2090299185.jpg" alt="Card Image 4">
    </div>
  </div>

  <div class="testimonials-section">
    <h2>What Our Visitors Say</h2>
    <div class="testimonials-container">
      <div class="testimonial-card">
        <p>"An absolutely breathtaking experience! The conservation efforts here are truly inspiring."</p>
        <h3>- Alex Johnson</h3>
      </div>
      <div class="testimonial-card">
        <p>"A must-visit place for nature lovers. The team is doing an amazing job protecting wildlife!"</p>
        <h3>- Priya Sharma</h3>
      </div>
      <div class="testimonial-card">
        <p>"Seeing the rescued animals thrive in a safe environment was heartwarming."</p>
        <h3>- David Lee</h3>
      </div>
      <div class="testimonial-card">
        <p>"A wonderful initiative! The sanctuary is a perfect blend of education and conservation."</p>
        <h3>- Emily Carter</h3>
      </div>
    </div>
  </div>

  <?php include 'f.php'; ?>
</body>
</html>
