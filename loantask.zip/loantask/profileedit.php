<?php
include 'connection.php';
session_start();

// Assuming the user ID is stored in the session
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';

if ($user_id) {
    // Fetch user data from the database
    $sql = "SELECT fullname, dob, gender, address, city, email, mobile, password, security_question, answer, farmsize, crops, bank_account FROM farmers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($fullname, $dob, $gender, $address, $city, $email, $mobile, $password, $security_question, $answer, $farmsize, $crops, $bank_account);
        $stmt->fetch();
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    echo "<script>alert('User not logged in.'); window.location.href='login.php';</script>";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-UsersSign</title>
    <link rel="stylesheet" href="usersign.css">
</head>
<script>
        function validateUserRegistration() {
            var fullname = document.getElementById('fullname').value.trim();
            var dob = document.getElementById('dob').value.trim();
            var gender = document.getElementById('gender').value.trim();
            var address = document.getElementById('address').value.trim();
            var city = document.getElementById('city').value.trim();
            var email = document.getElementById('email').value.trim();
            var mobile = document.getElementById('mobile').value.trim();
            var password = document.getElementById('password').value.trim();
            var securityQuestion = document.getElementById('security-question').value.trim();
            var answer = document.getElementById('answer').value.trim();
            var farmsize = document.getElementById('farmsize').value.trim();
            var crops = document.getElementById('crops').value.trim();
            var bankAccount = document.getElementById('bank-account').value.trim();

            if (fullname === '') {
                alert('Full Name is required');
                return false;
            }
            if (dob === '') {
                alert('Date of Birth is required');
                return false;
            }
            if (gender === '') {
                alert('Gender is required');
                return false;
            }
            if (address === '') {
                alert('Address is required');
                return false;
            }
            if (city === '') {
                alert('City is required');
                return false;
            }
            if (email === '') {
                alert('Email is required');
                return false;
            }
            if (!validateEmail(email)) {
                alert('Invalid email format');
                return false;
            }
            if (mobile === '') {
                alert('Mobile number is required');
                return false;
            }
            if (!validateMobile(mobile)) {
                alert('Invalid mobile number format');
                return false;
            }
            if (password === '') {
                alert('Password is required');
                return false;
            }
            if (securityQuestion === '') {
                alert('Security Question is required');
                return false;
            }
            if (answer === '') {
                alert('Answer is required');
                return false;
            }
            if (farmsize === '') {
                alert('Farm Size is required');
                return false;
            }
            if (isNaN(farmsize) || farmsize <= 0) {
                alert('Farm Size must be a positive number');
                return false;
            }
            if (crops === '') {
                alert('Type of Crops Grown is required');
                return false;
            }
            if (bankAccount === '') {
                alert('Bank Account Number is required');
                return false;
            }
            if (!validateBankAccount(bankAccount)) {
                alert('Invalid Bank Account Number format');
                return false;
            }

            return true;
        }

        function validateEmail(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        function validateMobile(mobile) {
            var re = /^[0-9]{10}$/;
            return re.test(mobile);
        }

        function validateBankAccount(bankAccount) {
            var re = /^[0-9]{9,13}$/;
            return re.test(bankAccount);
        }
    </script>
<body>
    <script src="usersign.js"></script>
    <div>
    <?php include 'h.php'; ?>

    <div class="mainbody">
        <div class="mainbody1">
            <h2><u>Profile Edit. </u></h2>
            <div class="signin-section ptb-100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                        <form name="form1" method="post" onsubmit="return validateUserRegistration()">
        <div class="form-group">
            <label for="fullname">Full Name:</label>
            <input type="text" id="fullname" name="fullname" value="<?php echo htmlspecialchars($fullname); ?>">
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($dob); ?>">
        </div>
        <div class="form-group">
            <label for="gender">Gender:</label>
            <select id="gender" name="gender">
                <option value="">Select</option>
                <option value="male" <?php echo ($gender == 'male') ? 'selected' : ''; ?>>Male</option>
                <option value="female" <?php echo ($gender == 'female') ? 'selected' : ''; ?>>Female</option>
                <option value="other" <?php echo ($gender == 'other') ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($address); ?></textarea>
        </div>
        <div class="form-group">
            <label for="city">City:</label>
            <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($city); ?>">
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
        </div>
        <div class="form-group">
            <label for="mobile">Mobile:</label>
            <input type="tel" id="mobile" name="mobile" value="<?php echo htmlspecialchars($mobile); ?>">
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value="<?php echo htmlspecialchars($password); ?>">
        </div>
        <div class="form-group">
            <label for="security-question">Security Question:</label>
            <select id="security-question" name="security-question">
                <option value="">Select</option>
                <option value="favourite-fruit" <?php echo ($security_question == 'favourite-fruit') ? 'selected' : ''; ?>>What is Your Favourite Fruit?</option>
                <option value="favourite-color" <?php echo ($security_question == 'favourite-color') ? 'selected' : ''; ?>>What is Your Favourite Color?</option>
                <option value="pet-name" <?php echo ($security_question == 'pet-name') ? 'selected' : ''; ?>>What is Your Pet's Name?</option>
            </select>
        </div>
        <div class="form-group">
            <label for="answer">Answer:</label>
            <input type="text" id="answer" name="answer" value="<?php echo htmlspecialchars($answer); ?>">
        </div>
        <div class="form-group">
            <label for="farmsize">Farm Size (in acres):</label>
            <input type="text" id="farmsize" name="farmsize" value="<?php echo htmlspecialchars($farmsize); ?>">
        </div>
        <div class="form-group">
            <label for="crops">Type of Crops Grown:</label>
            <select id="crops" name="crops">
                <option value="">Select</option>
                <option value="wheat" <?php echo ($crops == 'wheat') ? 'selected' : ''; ?>>Wheat</option>
                <option value="rice" <?php echo ($crops == 'rice') ? 'selected' : ''; ?>>Rice</option>
                <option value="corn" <?php echo ($crops == 'corn') ? 'selected' : ''; ?>>Corn</option>
                <option value="soybeans" <?php echo ($crops == 'soybeans') ? 'selected' : ''; ?>>Soybeans</option>
                <option value="other" <?php echo ($crops == 'other') ? 'selected' : ''; ?>>Other</option>
            </select>
        </div>
        <div class="form-group">
            <label for="bank-account">Bank Account Number:</label>
            <input type="text" id="bank-account" name="bank-account" value="<?php echo htmlspecialchars($bank_account); ?>">
        </div>
        <div class="form-group">
            <button type="submit">Update</button>
        </div>
    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>