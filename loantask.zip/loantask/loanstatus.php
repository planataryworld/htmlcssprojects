<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-HomePage</title>
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>


</style>
<body>
    <script src="validations.js"></script>
    <div> 
        <?php include 'h.php'; ?>

        <section class="mainbody">
            <section class="mainbody1">    
                <h2><u>Loan Status. </u></h2>
                <div class="bodypart1">
                <?php

include 'connection.php';

if (!isset($_SESSION['full_name'])) {
    header("Location: usersign.php");
    exit();
}

$full_name = $_SESSION['full_name'];

$sql = "SELECT * FROM loanapplication WHERE fullname = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $full_name);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="bodypart1">
    <!-- <h2>Loan Applications for <?php echo htmlspecialchars($full_name); ?></h2> -->
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Purpose of Loan</th>
            <th>loan_amount</th>
            <th>Repayment Period</th>
           
            <th>Status</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['id']) . "</td>
                        <td>" . htmlspecialchars($row['loanpurpose']) . "</td>
                        <td>" . htmlspecialchars($row['approved_loan_amount']) . "</td>
                        <td>" . htmlspecialchars($row['repayment_period']) . "</td>
                     
                        <td>" . htmlspecialchars($row['status']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No loan applications found</td></tr>";
        }
        ?>
    </table>
</div>

<?php
$stmt->close();
$conn->close();
?>
                </div>
            </section>
            
           
    </div>


<a href="#"class="scroll-to-top" id="scrollToTopBtn" title="Scroll to top"><i class="fas fa-arrow-up"></i></a>

<div class="button-container">
  
    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank">
        <i class="fab fa-whatsapp"></i> WhatsApp us
    </a>
</div>







</body>
</html>