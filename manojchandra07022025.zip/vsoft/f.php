

<style>
        body {
            color: #333;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .footer-container {
            width: 100%;
            display: flex;
            justify-content: space-around;
            align-items: flex-start;
            background: linear-gradient(to right, #e3f2fd, #ffffff); 
            padding: 30px 20px;
            border-top: 2px solid #ccc;
            flex-wrap: wrap;
        }

        .footer-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
            max-width: 200px;
        }

        .footer-section h3 {
            font-size: 18px;
            margin-bottom: 10px;
            color: #007BFF;
        }

        .footer-links a {
            color: #333;
            text-decoration: none;
            font-size: 16px;
            display: flex;
            flex-direction: column;
            font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 10px;
        }

        .footer-links a:hover {
            color: #007BFF;
            text-decoration: underline;
        }

        .social-icons a {
            font-size: 22px;
            color: #333;
            margin-right: 15px;
            transition: color 0.3s;
        }

        .social-icons a:hover {
            color: #007BFF;
        }

        .app-store img {
            width: 120px;
            border-radius: 5px;
        }

      
        @media screen and (max-width: 1024px) {
            .footer-container {
                flex-wrap: wrap;
                justify-content: center;
                text-align: center;
            }
            
            .footer-section {
                align-items: center;
                text-align: center;
            }
        }

        @media screen and (max-width: 768px) {
            .footer-container {
                flex-direction: column;
                align-items: center;
                gap: 20px;
            }

            .footer-section {
                width: 100%;
                align-items: center;
            }

            .social-icons {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>

    <div class="footer-container">
     
        <div class="footer-section">
            <h3>Company</h3>
            <div class="footer-links">
                <a href="#">About Us</a>
                <a href="#">Careers</a>
                <a href="#">Contact</a>
            </div>
        </div>

       
<div class="footer-section">
    <h3>Wildlife</h3>
    <div class="footer-links">
        <a href="#">Mammals</a>
        <a href="#">Birds</a>
        <a href="#">Reptiles</a>
        <a href="#">Amphibians</a>
    </div>
</div>


<div class="footer-section">
    <h3>Conservation</h3>
    <div class="footer-links">
        <a href="#">Habitat Protection</a>
        <a href="#">Wildlife Rescue</a>
        <a href="#">Endangered Species</a>
        <a href="#">Sustainable Practices</a>
    </div>
</div>


<div class="footer-section">
    <h3>Visitor Information</h3>
    <div class="footer-links">
        <a href="#">Opening Hours</a>
        <a href="#">Guided Tours</a>
        <a href="#">Volunteer Programs</a>
        <a href="#">Donate & Support</a>
    </div>
</div>

<div class="footer-section">
    <h3>Policies</h3>
    <div class="footer-links">
        <a href="#">Visitor Guidelines</a>
        <a href="#">Privacy Policy</a>
        <a href="#">Terms & Conditions</a>
    </div>
</div>


    
        <div class="footer-section">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href="https://www.facebook.com/" target="_blank" title="Facebook"><i class="fab fa-facebook"></i></a>
                <a href="https://www.instagram.com/" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://x.com/" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://www.whatsapp.com/" target="_blank" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
            </div>
            <div class="app-store">
                <img src="https://www.techgrapple.com/wp-content/uploads/2016/06/Google-Play-and-App-Store.jpg" alt="App Store and Google Play">
            </div>
        </div>
    </div>

</body>
</html>
