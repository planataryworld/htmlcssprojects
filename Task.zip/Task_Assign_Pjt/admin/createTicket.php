<?php 
include 'connection.php';
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
        echo "<script>alert('Error: User ID not set in session.'); window.history.back();</script>";
        exit();
    }

    include 'connection.php';

    $title = trim($_POST['title']) ?? '';
    $description = trim($_POST['description']) ?? '';
    $priority = $_POST['priority'] ?? '';
    $assigned_to = $_POST['assigned_to'] ?? '';
    $created_by = intval($_SESSION['id']);
    $created_at = date('Y-m-d H:i:s');

    // Check required fields
    if (empty($title) || empty($description) || empty($priority) || empty($assigned_to)) {
        echo "<script>alert('Please fill in all required fields.'); window.history.back();</script>";
        exit();
    }

    // File upload handling
    $file_path = null; // Default file path is null
    if (isset($_FILES['files']['name']) && !empty($_FILES['files']['name'][0])) {
        $upload_dir = "uploads/"; // Directory to save uploaded files
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Create directory if not exists
        }

        $file_name = basename($_FILES['files']['name'][0]);
        $target_file = $upload_dir . time() . "_" . $file_name; // Add timestamp to filename to avoid conflicts

        // Validate file size and type (optional)
        $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'docx'];
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (!in_array($file_extension, $allowed_types)) {
            echo "<script>alert('Invalid file type. Allowed types are: jpg, jpeg, png, pdf, docx.'); window.history.back();</script>";
            exit();
        }

        if ($_FILES['files']['size'][0] > 5 * 1024 * 1024) { // 5MB limit
            echo "<script>alert('File size must be less than 5MB.'); window.history.back();</script>";
            exit();
        }

        // Move uploaded file
        if (move_uploaded_file($_FILES['files']['tmp_name'][0], $target_file)) {
            $file_path = $target_file; // Save the file path
        } else {
            echo "<script>alert('Error uploading the file.'); window.history.back();</script>";
            exit();
        }
    }

    // Insert ticket into the database
    $stmt = $conn->prepare("INSERT INTO tickets (title, description, priority, assigned_to, created_by, created_at, file) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        echo "<script>alert('SQL Error: " . $conn->error . "'); window.history.back();</script>";
        exit();
    }

    $stmt->bind_param("ssssiss", $title, $description, $priority, $assigned_to, $created_by, $created_at, $file_path);

    if ($stmt->execute()) {
        echo "<script>
                alert('Ticket created successfully!');
                window.location.href = 'createticket.php';
              </script>";
    } else {
        echo "<script>
                alert('Error: Could not create ticket. SQL Error: " . $stmt->error . "');
                window.history.back();
              </script>";
    }

    $stmt->close();
    $conn->close();
}



// Fetch skills for a specific user via AJAX
if (isset($_GET['user_id'])) {
    $userId = intval($_GET['user_id']);
    $query = "SELECT skills FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    $skills = [];
    if ($row = $result->fetch_assoc()) {
        $skills = explode(',', $row['skills']); // Assuming skills are stored as comma-separated values
    }

    $stmt->close();
    $conn->close();

    header('Content-Type: application/json');
    echo json_encode($skills);
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background: #ff4d4d;
        }

        .container {
            padding: 20px;
        }

        .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            /* margin-left: 300px; */
            text-align: right;
        }

        .ticket-creation-form-container {
    width: 100%;
    margin-left: 450px;
    max-width: 500px;
    background: #ffffff;
    padding: 25px 30px;
    border-radius: 15px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    transition: transform 0.2s ease-in-out;
}

.ticket-creation-form-container:hover {
    transform: translateY(-5px);
}

.ticket-creation-form-container h2 {
    text-align: center;
    color: #333333;
    margin-bottom: 20px;
    font-size: 1.8em;
}


.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: #444444;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: border 0.3s;
    background-color: #f9f9f9;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #007bff;
    background: #fff;
    outline: none;
}


.form-group button {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    font-weight: bold;
    color: #ffffff;
    background: linear-gradient(45deg, #007bff, #0056b3);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s ease-in-out;
}

.form-group button:hover {
    background: linear-gradient(45deg, #0056b3, #003f7f);
}
        

      

       

        



    </style>
    
    <?php 
include 'sidenav2.php'?>
</head>
<body>
<script src="adminproductmain.js"></script>
    <div class="container">
        <div class="description">
            
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
                
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
               
        </div>

        
    </div>
    <div class="ticket-creation-form-container">
        <h2>Create a New Ticket</h2>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Ticket Title</label>
                <input type="text" id="title" name="title" placeholder="Enter ticket title" required>
            </div>
            
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" placeholder="Provide a detailed description" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <label for="priority">Priority</label>
                <select id="priority" name="priority" required>
                    <option value="">--- Select ---</option>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                </select>
            </div>

            <div class="form-group">
                <label for="assigned_to">Assign To</label>
                <select id="assigned_to" name="assigned_to" required>
                    <option value="" disabled selected>Select a user</option>
                    <?php
                    include 'connection.php';
                    $query = "SELECT id, CONCAT(firstname, ' ', lastname) AS full_name FROM users";
                    $result = $conn->query($query);

                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['id'] . "'>" . $row['full_name'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No users available</option>";
                    }

                    $conn->close();
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="skills">Skills</label>
                <select id="skills" name="skills[]" multiple>
                    <option value="">Select a user first</option>
                </select>
            </div>

            <div class="form-group">
                <label for="files">Attach Files</label>
                <input type="file" id="files" name="files[]" multiple>
            </div>

            <div class="form-group">
                <button type="submit">Create Ticket</button>
            </div>
        </form>
    </div>

    <script>
        document.getElementById('assigned_to').addEventListener('change', function () {
            const userId = this.value;
            const skillsDropdown = document.getElementById('skills');

            if (userId) {
                fetch(`createticket.php?user_id=${userId}`)
                    .then(response => response.json())
                    .then(skills => {
                        skillsDropdown.innerHTML = ''; // Clear previous options
                        if (skills.length > 0) {
                            skills.forEach(skill => {
                                const option = document.createElement('option');
                                option.value = skill;
                                option.textContent = skill;
                                skillsDropdown.appendChild(option);
                            });
                        } else {
                            skillsDropdown.innerHTML = '<option value="">No skills available</option>';
                        }
                    })
                    .catch(error => console.error('Error fetching skills:', error));
            }
        });
    </script>
</body>
</html>
    
    