<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $approved_loan_amount = $_POST['approved_loan_amount'];
    $status = $_POST['status'];

    // Update the loan status in the database
    $query = "UPDATE loanapplication SET approved_loan_amount = ?, status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("dsi", $approved_loan_amount, $status, $id);
    
    if ($stmt->execute()) {
        
        // Fetch user details
        $userQuery = "SELECT fullname, email FROM loanapplication WHERE id = ?";
        $stmt = $conn->prepare($userQuery);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if ($status == "Approved" && $user) {
            $to = $user['email']; // Ensure 'email' column exists in DB
            $subject = "Loan Approval Notification";
            $message = "Dear " . $user['fullname'] . ",\n\nYour loan of amount $" . $approved_loan_amount . " has been approved.\n\nThank you!";
            $headers = "From: noreply@yourdomain.com\r\n";
            $headers .= "Reply-To: support@yourdomain.com\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
            
            // Send email
            if (mail($to, $subject, $message, $headers)) {
                echo "Loan updated and email sent successfully!";
            } else {
                echo "Loan updated, but email sending failed.";
            }
        } else {
            echo "Loan updated successfully!";
        }
    } else {
        echo "Error updating loan.";
    }
}
?>
