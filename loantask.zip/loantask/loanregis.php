<<?php
include 'connection.php';
session_start();
$fullname = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '';
$email = isset($_SESSION['email']) ? $_SESSION['email'] : ''; 
$home_phone = isset($_SESSION['phone']) ? $_SESSION['phone'] : ''; // Ensure home_phone is set

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan = trim($_POST['loan_type'] ?? '');
    $loan_purpose = trim($_POST['loan_purpose'] ?? '');
    $loan_amount = trim($_POST['loan_amount'] ?? '');
    $repayment_period = trim($_POST['repayment_period'] ?? '');
    $interest_rate = trim($_POST['interest_rate'] ?? '');
    $project_location = trim($_POST['project_location'] ?? '');
    $fullname = trim($_POST['fullname'] ?? '');
    $postal_address = trim($_POST['postal_address'] ?? '');
    $physical_address = trim($_POST['physical_address'] ?? '');
    $home_phone = trim($_POST['home_phone'] ?? '');
    $email = trim($_POST['email'] ?? '');

    // Check if file is uploaded
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file = $_FILES['file'];

        $target_dir = "../uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $filename = basename($file["name"]); // Extract only the file name
        $target_file = $target_dir . $filename; // Full path for uploading
        $uploadOk = 1;
        $fileType = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "<script>alert('Sorry, file already exists.'); window.history.back();</script>";
            $uploadOk = 0;
        }

        // Check file size
        if ($file["size"] > 500000) {
            echo "<script>alert('Sorry, your file is too large.'); window.history.back();</script>";
            $uploadOk = 0;
        }

        // Allow only certain file formats
        if (!in_array($fileType, ['pdf', 'doc', 'docx'])) {
            echo "<script>alert('Sorry, only PDF, DOC & DOCX files are allowed.'); window.history.back();</script>";
            $uploadOk = 0;
        }

        // Upload file
        if ($uploadOk == 1) {
            if (move_uploaded_file($file["tmp_name"], $target_file)) {
                // Store only the file name in the database
                $sql = "INSERT INTO loanapplication (loanpurpose, purpose_of_loan, loan_amount, repayment_period, interestrate, location, fullname, postaladdress, physicaladdress, telephone, email, document) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssss", $loan, $loan_purpose, $loan_amount, $repayment_period, $interest_rate, $project_location, $fullname, $postal_address, $physical_address, $home_phone, $email, $filename);

                if ($stmt->execute()) {
                    echo "<script>alert('Loan application submitted successfully');
                    window.location.href='homepagem.php'</script>";
                } else {
                    echo "<script>alert('An error occurred. Please try again.'); window.history.back();</script>";
                }

                $stmt->close();
            } else {
                echo "<script>alert('Sorry, there was an error uploading your file.'); window.history.back();</script>";
            }
        }
    } else {
        echo "<script>alert('Please upload a valid document file.'); window.history.back();</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Application Form</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<style>
 body{
    padding: 0;
    width: 80%;
    background-color: rgb(210, 234, 249);
}
.container {
    width: 60%;
    margin: 0 auto;
    border: 1px solid #000;
    padding: 20px;
}
h2 {
    color: #007BFF;
}
label {
    font-weight: bold;
    display: block;
    margin-top: 10px;
}
input, textarea, select {
    width: 100%;
    padding: 5px;
    margin-top: 5px;
    border: 1px solid #000;
}
.row {
    display: flex;
    justify-content: space-between;
}
.row input {
    width: 48%;
}
.checkbox-group {
    display: flex;
    gap: 10px;
}
.mainbody {
    height: auto;
    width: 100%;
    background-color: white;
    display: flex;
    flex-direction: row;
}
.mainbody1 {
    margin-top: 25px;
    background-color: rgb(238, 244, 248);
    width: 80%;
    margin-left: 100px;
}
.mainbody1 h2 {
    padding-left: 45px;
    padding-top: 5px;
    width: 95%;
    height: 48px;
    background-color: #b3c5f1;
}
button {
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    margin-top: 20px;
}
</style>
<script>
        function validateLoanApplication() {
            var loanPurpose = document.getElementById('loan_purpose').value.trim();
            var loanAmount = document.getElementById('loan_amount').value.trim();
            var repaymentPeriod = document.getElementById('repayment_period').value.trim();
            var projectLocation = document.getElementById('project_location').value.trim();
            var fullname = document.getElementById('fullname').value.trim();
            var postalAddress = document.getElementById('postal_address').value.trim();
            var physicalAddress = document.getElementById('physical_address').value.trim();
            var homePhone = document.getElementById('home_phone').value.trim();
            var email = document.getElementById('email').value.trim();
            var file = document.getElementById('file').value.trim();

            if (loanPurpose === '') {
                alert('Purpose of Loan is required');
                return false;
            }
            if (loanAmount === '') {
                alert('Loan Amount is required');
                return false;
            }
            if (repaymentPeriod === '') {
                alert('Repayment Period is required');
                return false;
            }
            if (projectLocation === '') {
                alert('Project Location is required');
                return false;
            }
            if (fullname === '') {
                alert('Full Name is required');
                return false;
            }
            if (postalAddress === '') {
                alert('Postal Address is required');
                return false;
            }
            if (physicalAddress === '') {
                alert('Physical Address is required');
                return false;
            }
            if (homePhone === '') {
                alert('Home Phone is required');
                return false;
            }
            if (!validatePhone(homePhone)) {
                alert('Invalid Home Phone format');
                return false;
            }
            if (email === '') {
                alert('Email is required');
                return false;
            }
            if (!validateEmail(email)) {
                alert('Invalid email format');
                return false;
            }
            if (file === '') {
                alert('Supporting Document is required');
                return false;
            }

            return true;
        }

        function validateEmail(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        function validatePhone(phone) {
            var re = /^[0-9]{10}$/;
            return re.test(phone);
        }
    </script>
<body>
    <div>
    <?php include 'h.php'; ?>

    <div class="mainbody">
        <div class="mainbody1">
            <h2><u>Loans Application Form. </u></h2>
            <div class="container">
            <form method="post" enctype="multipart/form-data" onsubmit="return validateLoanApplication()">
                    <h2>1. PROPOSE LOAN REQUIREMENT</h2>
                    <label for="loan_type">Purpose of Loan:</label>
                    <input type="text" id="loan_type" name="loan_type" >
                    <label for="loan_purpose">Loan Type:</label>
                    <select id="loan_purpose" name="loan_purpose"  onchange="fetchLoanAmount()">
                        <option value="">Select</option>
                        <option value="kisan-credit-card-scheme">kisan-credit-card-scheme</option>
                        <option value="krishi-mitra-card-scheme">krishi-mitra-card-scheme</option>
                        <option value="farm-machinery-loans">farm-machinery-loans</option>
                        <option value="Dairy-Loans">Dairy-Loans</option>
                    </select>

                    <label for="loan_amount">Loan Amount applied for:</label>
                    <input type="text" id="loan_amount" name="loan_amount" readonly>

                    <label for="repayment_period">Proposed Repayment Period (Years):</label>
                      <input type="text" id="repayment_period" name="repayment_period" readonly>


                      <label for="interest_rate">Interest Rate (%):</label>
                      <input type="text" id="interest_rate" name="interest_rate" readonly>

                   
                    <h2>2. BACKGROUND INFORMATION OF THE APPLICANT</h2>
                    <label for="fullname">Full Name of the Applicant (Company or Individual):</label>
                    <input type="text" id="fullname" name="fullname" value="<?php echo htmlspecialchars($fullname); ?>">
                    
                    <label for="postal_address">Postal Address:</label>
                    <input type="text" id="postal_address" name="postal_address" >
                    <label for="physical_address">Physical Address:</label>
                    <input type="text" id="physical_address" name="physical_address" >

                    <h3>Telephone</h3>
                    <div class="row">
                        <input type="text" id="home_phone" name="home_phone" placeholder="Home" value="<?php echo htmlspecialchars($home_phone); ?>">
                    </div>
                  
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
                    
                    <label for="file">Upload Supporting Document:</label>
                    <input type="file" id="file" name="file" >
                    
                    <div class="form-group">
                        <button type="submit">Apply</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function fetchLoanAmount() {
    var loanPurpose = $('#loan_purpose').val();
    if (loanPurpose) {
        $.ajax({
            url: 'fetch_loan_amount.php', 
            type: 'POST',
            data: { loan_purpose: loanPurpose },
            dataType: 'json',
            success: function(response) {
                if (response) {
                    $('#loan_amount').val(response.loan_amount); 
                    $('#repayment_period').val(response.repayment_period); 
                    $('#interest_rate').val(response.interest_rate); 
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", error);
                alert("Failed to fetch loan details.");
            }
        });
    } else {
        $('#loan_amount').val('');
        $('#repayment_period').val('');
        $('#interest_rate').val('');
    }
}
</script>

</body>
</html>