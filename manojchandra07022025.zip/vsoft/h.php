
    

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
        }

        
        .container {
            position: fixed;
            top: 0;
            width: 100%;
            background: linear-gradient(90deg, rgb(185, 255, 250), #ffd3b6);
            z-index: 1000;
            padding: 5px 0;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        
        .navbar {
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 10px 80px;
        }

        
        .logo img {
            height: 80px;
            width: auto;
            max-width: 100%;
        }

        
        .menu-toggle {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }

       
        .main-menu ul {
            display: flex;
            list-style: none;
            gap: 20px;
            font-size: 18px;
        }

        .main-menu ul li a {
            text-decoration: none;
            color: black;
            font-weight: bold;
            transition: color 0.3s;
            padding: 10px;
        }

        .main-menu ul li a:hover {
            color: cadetblue;
        }

       
        @media (max-width: 1024px) {
            .navbar {
                padding: 10px 20px;
            }
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: block;
                font-size: 28px;
            }

            .main-menu {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                width: 100%;
                background: linear-gradient(90deg, rgb(185, 255, 250), #ffd3b6);
                text-align: center;
                padding: 10px 0;
                box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            }

            .main-menu ul {
                flex-direction: column;
                padding: 0;
            }

            .main-menu ul li {
                padding: 12px 0;
            }

            .main-menu.active {
                display: block;
                animation: slideDown 0.3s ease-in-out;
            }
        }

       
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

    </style>
</head>
<body>

    <div class="container">
        <div class="navbar">
            <div class="logo">
                <img src="https://wildlifesos.org/wp-content/uploads/2020/11/wsos-Bear-Logo-border-85x130-1.png" alt="logo">
            </div>
            <span class="menu-toggle">&#9776;</span>
            <nav class="main-menu">
                <ul>
                    <li><a href="homepage.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <!-- <li><a href="#">Login</a></li> -->
                </ul>
            </nav>
        </div>
    </div>

    <script>
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.querySelector('.main-menu').classList.toggle('active');
        });
    </script>

</body>
</html>
