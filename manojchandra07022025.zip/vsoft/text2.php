<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .mainbody {
            background: linear-gradient(90deg, #ffdab9, #ffd3b6);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .dashboard-header {
            text-align: center;
        }

        .dashboard-header h1, .dashboard-header p {
            margin: 10px 0;
            color: black;
        }

        .container {
            display: flex;
            justify-content: center;
            width: 100%;
        }

        .classes {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 45px;
            padding: 10px;
            max-width: 1200px; /* Prevents stretching */
            width: 100%;
            margin-left: 290px; 
            transition: margin-left 0.3s ease-in-out;
        }

        .cls1, .cls2, .cls3, .cls4, .cls5, .cls6 {
            box-sizing: border-box;
            height: 180px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f9f9f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .cls1:hover, .cls2:hover, .cls3:hover, .cls4:hover, .cls5:hover, .cls6:hover {
            transform: scale(1.05);
            box-shadow: 5px 10px 20px rgba(0, 0, 0, 0.3);
        }

        .cls1 h3, .cls2 h3, .cls3 h3, .cls4 h3, .cls5 h3, .cls6 h3 {
            color: black;
            font-size: 20px;
        }

        .cls1 i, .cls2 i, .cls3 i, .cls4 i, .cls5 i, .cls6 i {
            font-size: 30px;
            color: #ff4d4d;
        }

        .search-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
        }

        .search-bar {
            width: 90%;
            max-width: 300px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 14px;
            background-color: #f2f2f2;
        }

        .cancel {
            font-size: 14px;
            color: black;
            cursor: pointer;
            padding: 8px 12px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 5px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .classes {
                margin-left: 0; /* Remove sidebar offset */
                max-width: 100%;
            }
        }

        @media (max-width: 1024px) {
            .classes {
                grid-template-columns: repeat(2, 1fr);
               
            }
        }

        @media (max-width: 768px) {
            .dashboard-header h1 {
                font-size: 24px;
            }

            .dashboard-header p {
                font-size: 14px;
            }

            .classes {
                grid-template-columns: 1fr;
            }

            .cls1, .cls2, .cls3, .cls4, .cls5, .cls6 {
                height: 150px;
            }
        }
    </style>
</head>
<body>
   <?php include 'sidenav.php';  ?>
    <div class="mainbody">
        <div class="dashboard-header">
            <h1>Dashboard</h1>
            <p style="color: black; font-size: 18px;">Welcome back, 
                <?php
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
                ?>!
            </p>
        </div>

        <div class="search-container">
            <input type="text" class="search-bar" placeholder="Search">
            <span class="cancel">Cancel</span>
            <!-- <span class="cancel">Select Theme</span>
            <span class="cancel">Default</span> -->
        </div>

        <section>
        <div class="container">
  <div class="classes">
    <div class="cls1">
      <h3>Total Animals</h3>
      <i class="fas fa-paw"></i>
    </div>
    <div class="cls2">
      <h3>Conservation Projects</h3>
      <i class="fas fa-leaf"></i>
    </div>
    <div class="cls3">
      <h3>Approved Projects</h3>
      <i class="fas fa-check-circle"></i>
    </div>
    <div class="cls4">
      <h3>Rejected Projects</h3>
      <i class="fas fa-times-circle"></i>
    </div>
    <div class="cls5">
      <h3>Donations</h3>
      <i class="fas fa-hand-holding-usd"></i>
    </div>
    <div class="cls6">
      <h3>Volunteers</h3>
      <i class="fas fa-users"></i>
    </div>
  </div>
</div>
        </section>
    </div>
</body>
</html>
