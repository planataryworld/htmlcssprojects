<?php 
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
        box-sizing: border-box;
        margin: 0;
        font-family: Arial, sans-serif;
        background: #ff4d4d;
        overflow-x: hidden; 
      }

      .container {
        margin-left: 250px;
        padding: 20px;
        width: 100%;
      }
      .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 900px;
            /* text-align: center; */
        }

      .student-database-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        padding: 20px;
        background-color: #fff;
        width: 80%; 
        max-width: 1200px; 
        margin: 20px auto;
        box-shadow: none;
        border-radius: 10px;
        margin-left: 300px;
        box-sizing: border-box; 
      }

      .student-database-container h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
      }

     
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        border-radius: 10px;
        overflow: hidden;
      }

    
      table, th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
      }

     
      th {
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
      }

      tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      tr:hover {
        background-color: #f1f1f1;
      }

     
      td {
        font-size: 14px;
        color: #333;
      }

      .student-database-container table {
        margin: 0 auto;
        width: 100%;
      }
    </style>

    <?php 
    include 'sidenav2.php'; 
    ?>
</head>
<body>

    <div class="container">
        <div class="description">
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
               
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
        </div>
    </div>

    <div class="student-database-container">
        <h3>Active Tickets</h3>
        <?php
       
        include 'connection.php';

        
        $query = "SELECT t.id, t.title, t.description, t.priority, t.status, t.created_at, CONCAT(u.firstname, ' ', u.lastname) AS assigned_to
          FROM tickets t
          LEFT JOIN users u ON t.assigned_to = u.id
          WHERE t.status = 'open'";

   
        $result = $conn->query($query);

       
        if ($result && $result->num_rows > 0) {
         
            echo "<table border='1'>
                    <tr>
                        <th>Ticket ID</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Assigned To</th>
                    </tr>";

           
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['id'] . "</td>
                        <td>" . htmlspecialchars($row['title']) . "</td>
                        <td>" . htmlspecialchars($row['description']) . "</td>
                        <td>" . ucfirst($row['priority']) . "</td>
                        <td>" . ucfirst($row['status']) . "</td>
                        <td>" . $row['created_at'] . "</td>
                        <td>" . ($row['assigned_to'] ? htmlspecialchars($row['assigned_to']) : 'Not Assigned') . "</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<div class='student-database-container'><h3>No tickets found</h3></div>";
        }

        // Close the database connection
        $conn->close();
        ?>
    </div>
</body>
</html>
