<?php
session_start(); // Start the session at the top
include 'connection.php';

// Check if ticket_id is passed in the URL
if (isset($_GET['id'])) {
    $ticket_id = intval($_GET['id']); // Get ticket ID from URL

    // Fetch the ticket details from the database
    $query = "SELECT id, title, description, priority, status FROM tickets WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $ticket = $result->fetch_assoc();
    } else {
        echo "<script>alert('Ticket not found'); window.location.href = 'view_tickets.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No ticket ID provided'); window.location.href = 'view_tickets.php';</script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data and sanitize it
    $title = trim($_POST['title']) ?? '';
    $description = trim($_POST['description']) ?? '';
    $priority = $_POST['priority'] ?? '';
    $status = $_POST['status'] ?? '';

    if (empty($title) || empty($description) || empty($priority) || empty($status)) {
        echo "<script>alert('Please fill in all required fields');</script>";
        return;
    } else {
        // Update the ticket in the database
        $update_query = "UPDATE tickets SET title = ?, description = ?, priority = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("ssssi", $title, $description, $priority, $status, $ticket_id);

        if ($stmt->execute()) {
            echo "<script>alert('Ticket updated successfully'); window.location.href = 'allTicket.php';</script>";
        } else {
            echo "<script>alert('Error updating ticket'); window.history.back();</script>";
        }

        $stmt->close();
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
    box-sizing: border-box;
    margin: 0;
    font-family: Arial, sans-serif;
    background: #ff4d4d;
    height: 100vh; 
    display: flex;
   
}


        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 900px;
            
        }

.ticket-creation-form-container {
    width: 100%;
    max-width: 800px; 
    background: #ffffff;
    padding: 25px 30px;
    border-radius: 15px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    transition: transform 0.2s ease-in-out;
    margin-left: 200px;
}

.ticket-creation-form-container:hover {
    transform: translateY(-5px);
}

.ticket-creation-form-container h2 {
    text-align: center;
    color: #333333;
    margin-bottom: 20px;
    font-size: 1.8em;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: #444444;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: border 0.3s;
    background-color: #f9f9f9;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    border-color: #007bff;
    background: #fff;
    outline: none;
}

.form-group button {
    width: 100%;
    padding: 12px;
    font-size: 1rem;
    font-weight: bold;
    color: #ffffff;
    background: linear-gradient(45deg, #007bff, #0056b3);
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s ease-in-out;
}

.form-group button:hover {
    background: linear-gradient(45deg, #0056b3, #003f7f);
}


    </style>
    
    <?php 
include 'sidenav2.php'?>
</head>
<body>
<script src="adminproductmain.js"></script>
    <div class="container">
        <div class="description">
            
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
                
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
               
        </div>

        
    </div>
    <div class="ticket-edit-form-container">
        <h2>Edit Ticket</h2>
        <form method="POST" action="editticket.php?id=<?php echo $ticket_id; ?>">
            <div class="form-group">
                <label for="title">Ticket Title</label>
                <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($ticket['title']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($ticket['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="priority">Priority</label>
                <select id="priority" name="priority" required>
                    <option value="low" <?php echo ($ticket['priority'] == 'low' ? 'selected' : ''); ?>>Low</option>
                    <option value="medium" <?php echo ($ticket['priority'] == 'medium' ? 'selected' : ''); ?>>Medium</option>
                    <option value="high" <?php echo ($ticket['priority'] == 'high' ? 'selected' : ''); ?>>High</option>
                </select>
            </div>
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status" required>
                    <option value="open" <?php echo ($ticket['status'] == 'open' ? 'selected' : ''); ?>>Open</option>
                    <option value="in-progress" <?php echo ($ticket['status'] == 'in-progress' ? 'selected' : ''); ?>>In Progress</option>
                    <option value="closed" <?php echo ($ticket['status'] == 'closed' ? 'selected' : ''); ?>>Closed</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Update Ticket</button>
            </div>
        </form>
    </div>
</body>
</html>
    