<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: adminlogin.php");
    exit();
}
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "finance";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all loan applications
$sql = "SELECT * FROM loan_applications ORDER BY id ASC";
$result = $conn->query($sql);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $loan_id = $_POST['loan_id'];
    $email = $_POST['email'];
    $status = $_POST['status'];

    // Update loan application status
    $update_sql = "UPDATE loan_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $loan_id);
    
    if ($stmt->execute()) {
        // Insert or Update customer notification
        $notif_sql = "INSERT INTO customer_status (email, loan_id, status)
                      VALUES (?, ?, ?)
                      ON DUPLICATE KEY UPDATE status = ?";
        $notif_stmt = $conn->prepare($notif_sql);
        $notif_stmt->bind_param("siss", $email, $loan_id, $status, $status);
        $notif_stmt->execute();
        $notif_stmt->close();

        echo "<script>alert('Loan status updated successfully!'); window.location.href='adminservicesmain.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin_Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background:rgb(150, 227, 247);
        }

        .container {
            padding: 20px;
        }

        .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 300px;
        }

        .toolbar {
            display: flex;
            width: 47%;
            justify-content: end;
            align-items: flex-end;
            flex-direction: row;
            gap: 45px;
            padding: 10px;
            background-color: rgb(192, 187, 187);
            border-radius: 8px;
            margin-top: 20px;
            margin-left: 780px;
        }

        .sort {
            display: flex;
            align-items: center;
            color: #333;
            cursor: pointer;
           
            margin-bottom: 11px;
        }

        .filter-icon {
            font-size: 16px;
            margin-right: 4px;
        }

        .search-container {
            flex-grow: 1;
            display: flex;
        }

        .search-bar {
            width: 250px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
        }

        .search-bar::placeholder {
            color: #aaa;
        }

        .cancel {
            color:rgb(230, 0, 0);
            font-weight: bold;
            cursor: pointer;
            font-size: 18px;
            padding: 8px;
        }

        .add-product {
            background-color: rgb(22, 123, 148);
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            width: 15vw;
            height: 5vh;
        }

        .add-product:hover {
            background-color: #c0392b;
        }

        .header {
            background-color: #E74C3C;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        .add-product-btn {
            margin: 20px;
            background-color: #E74C3C;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .add-product-btn:hover {
            opacity: 0.8;
        }

        .modal {
            display: none;
            position: absolute;
            top: 0;
            left: 0;
            width: 130%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 100%;
            max-width: 800px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: rgb(22, 123, 148); / Adjusted background color for better contrast /
            color: white;
            padding: 10px 20px;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .close-btn {
            color: blue;
            font-size: 24px;
            cursor: pointer;
        }

        .form-row {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column; / Stacked label and input /
        }

        .form-row label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        .input-container {
            display: flex;
            align-items: center;
        }

        .input-container i {
            margin-right: 10px;
            font-size: 18px;
            color: #2980B9;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-left: 19.4%;

        }
        th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
            color: black;
        }
        th {
            background-color: #f2f2f2;
        }
        select, button {
            padding: 5px;
        }
        /* .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
        } */

        .delete-btn, .download-btn { padding: 5px 10px; border: none; cursor: pointer; }
        .delete-btn { background-color: red; color: white; }
        .download-btn { background-color: green; color: white; }


    </style>

<?php
    include 'adminservices.php';
    ?> 
</head>
<body>


<h2 style="text-align: center;">Loan Applications</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Loan Amount</th>
        <th>Status</th>
        <th>Document</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row["id"]; ?></td>
            <td><?php echo $row["name"]; ?></td>
            <td><?php echo $row["email"]; ?></td>
            <td><?php echo $row["loan_amount"]; ?></td>
            <td>
                <form action="update_status.php" method="post">
                    <input type="hidden" name="loan_id" value="<?php echo $row["id"]; ?>">
                    <input type="hidden" name="email" value="<?php echo $row["email"]; ?>">
                    <select name="status">
                        <option value="Pending" <?php if ($row["status"] == "Pending") echo "selected"; ?>>Pending</option>
                        <option value="Approved" <?php if ($row["status"] == "Approved") echo "selected"; ?>>Approved</option>
                        <option value="Canceled" <?php if ($row["status"] == "Canceled") echo "selected"; ?>>Canceled</option>
                    </select>
                    <button type="submit">Update</button>
                </form>
            </td>
            <td>
                <?php if (!empty($row["document_path"])) { ?>
                    <a href="<?php echo $row["document_path"]; ?>" class="download-btn" download>Download</a>
                <?php } else { echo "No Document"; } ?>
            </td>
            <td>
                <button class="delete-btn" onclick="confirmDelete(<?php echo $row['id']; ?>)">Delete</button>
            </td>
        </tr>
    <?php } ?>
</table>

                        
  
<script>
        function confirmDelete(loanId) {
            let confirmation = confirm("Are you sure you want to delete this loan application?");
            if (confirmation) {
                window.location.href = "delete_loan.php?id=" + loanId;
            }
        }
    </script>
  
      
    
</body>
</html>