<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Responsive Wildlife & Interior Design Website</title>
  <link rel="stylesheet" href="fontawesome-free-6.7.2-web/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    :root {
      font-size: 16px;
    }

    body {
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      margin: 0;
      font-family: Georgia, 'Times New Roman', Times, serif;
    }

    .banner {
      position: relative;
      width: 100%;
      height: 100vh;
      background: url('https://media.geeksforgeeks.org/wp-content/uploads/20230802132058/Wildlife-Sanctuary.webp') no-repeat center center;
      background-size: cover;
      display: flex;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: white;
      padding: 20px;
    }

    .banner-content {
      background: rgba(0, 0, 0, 0.2);
      padding: 20px;
      border-radius: 10px;
      width: 60%;
    }

    .banner h1 {
      font-size: 2.5rem;
      font-weight: bold;
    }

    .banner p {
      font-size: 1.2rem;
      margin-top: 15px;
      line-height: 1.6;
    }

    .cta-btn {
      display: inline-block;
      margin-top: 30px;
      padding: 12px 24px;
      background: rgb(255, 0, 0);
      color: white;
      text-decoration: none;
      border-radius: 30px;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .cta-btn:hover {
      background: darkred;
    }

    .mainpara {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      padding: 40px 20px;
      text-align: center;
    }

    .submainpara h1 {
      font-size: 2.2rem;
      text-align: center;
      margin-bottom: 20px;
    }

    .para1 {
      width: 100%;
      padding: 10px;
      box-shadow: 0 4px 8px rgba(255, 105, 180, 0.3);
      border-radius: 10px;
      background: #ffe6f2;
      text-align: justify;
    }

    .para1 p {
      font-size: 1rem;
      line-height: 1.8;
      padding: 10px;
    }

    .section-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      padding: 40px 20px;
      text-align: center;
    }

    .section {
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      margin: 20px;
      padding: 20px;
      width: calc(50% - 40px);
      text-align: center;
      transition: transform 0.3s ease;
    }

    .section:hover {
      transform: scale(1.05);
    }

    .section h2 {
      font-size: 1.8rem;
      margin-bottom: 10px;
    }

    .section p {
      font-size: 1rem;
      text-align: justify;
      padding: 10px;
    }

    @media screen and (max-width: 1024px) {
      .banner h1 {
        font-size: 2.5rem;
      }

      .banner-content {
        width: 75%;
      }

      .para1 {
        width: 90%;
      }

      .section {
        width: calc(50% - 40px);
      }
    }

    @media screen and (max-width: 768px) {
      .banner h1 {
        font-size: 2rem;
      }

      .banner-content {
        width: 85%;
      }

      .submainpara h1 {
        font-size: 2rem;
      }

      .para1 {
        width: 95%;
      }

      .section {
        width: calc(100% - 40px);
      }
    }

    @media screen and (max-width: 480px) {
      .banner h1 {
        font-size: 1.5rem;
      }

      .banner-content {
        width: 90%;
      }

      .para1 {
        width: 100%;
        padding: 15px;
      }

      .section {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <?php include 'h.php'; ?>

  <div class="banner">
    <div class="banner-content">
      <h1>About WildLife SOS</h1>
      <p>We follow a comprehensive approach to saving India’s wildlife. As we continue to develop and improve our rescue and medical resources, our Elephant Hospital and conservation and care centres, our research and partnerships, and our talented and dedicated staff, we take a holistic view of saving both individual animals, as well as protecting an entire species.</p>
      <a href="#" class="cta-btn">Explore More</a>
    </div>
  </div>

  <section>
    <div class="mainpara">
      <div class="submainpara"> 
        <h1>Welcome to About WildLife SOS</h1>
        <div class="para1">
          <p>In 1995, a group of individuals determined to conserve India’s rich natural heritage began operating a rescue centre out of a small garage in New Delhi. Their goal was simple – to aid wildlife in distress and expand India’s core value of the right to freedom and dignity to the realm of animals. Kartick Satyanarayan and Geeta Seshamani’s grit and determination gave birth to Wildlife SOS. Today, we have evolved into an organisation actively protecting India’s precious wildlife, conserving habitats, studying biodiversity, conducting research, and creating alternative and sustainable livelihoods for erstwhile poacher communities, or communities dependent on wildlife for sustenance. We are the largest wildlife rescue organisation in India and run 12 wildlife rescue centres all over the country.</p>
          <p>Kartick Satyanarayan and Geeta Seshamani, with their shared enthusiasm, dedicated themselves to the mission of resolving the abusive practice of ‘dancing’ bears in India completely. The initial days were very difficult due to a lack of support and funding. Geeta’s foresight in creating Wildlife SOS as an arm of her existing rescue operation, Friendicoes SECA, allowed the two organisations to share knowledge and resources. The team learned and made its way through the initial challenges of addressing the needs of urban wildlife suffering from habitat encroachment – a result of the surging population growth in India.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="section-container">
    <div class="section">
      <h2>Mission</h2>
      <p>Our mission is to protect and conserve India's natural heritage, forest and wildlife wealth. We aim to create sustainable livelihoods for communities dependent on wildlife and to educate the public about the importance of wildlife conservation.</p>
    </div>
    <div class="section">
      <h2>Vision</h2>
      <p>Our vision is to create a world where humans and wildlife coexist in harmony. We strive to ensure that future generations can experience the beauty and diversity of India's wildlife in their natural habitats.</p>
    </div>
  </section>

  <?php include 'f.php'; ?>
</body>
</html>