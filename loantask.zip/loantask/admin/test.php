<?php 
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
        box-sizing: border-box;
        margin: 0;
        font-family: Arial, sans-serif;
        background: #ff4d4d;
        overflow-x: hidden; 
      }

      .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 900px;
          
        }
      .container {
        margin-left: 250px;
        padding: 20px;
        width: 100%;
      }

      .student-database-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        padding: 20px;
        background-color: #fff;
        width: 80%; 
        max-width: 1200px; 
        margin: 20px auto; 
        box-shadow: none;
        border-radius: 10px;
        margin-left: 300px;
        box-sizing: border-box; 
      }

      .student-database-container h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
      }

     
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        border-radius: 10px;
        overflow: hidden;
      }

     
      table, th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
      }

      
      th {
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
      }

     
      tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      tr:hover {
        background-color: #f1f1f1;
      }

      
      td {
        font-size: 14px;
        color: #333;
      }

      .student-database-container table {
        margin: 0 auto;
        width: 100%;
      }
    </style>

    <?php 
    include 'sidenav2.php'; 
    ?>
</head>
<body>

    <div class="container">
        <div class="description">
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
               
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
        </div>
    </div>

    <div class="student-database-container">
    <h3>Users</h3>
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Search tickets..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit">Search</button>
    </form>
    <?php
include 'connection.php';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$query = "SELECT id, fullname, dob, gender, address, email, mobile, farmsize, bank_account, reg_date FROM farmers";

if ($search) {
    $query .= " WHERE fullname LIKE '%$search%' OR dob LIKE '%$search%' OR gender LIKE '%$search%' OR address LIKE '%$search%' OR email LIKE '%$search%' OR mobile LIKE '%$search%' OR farmsize LIKE '%$search%' OR bank_account LIKE '%$search%' OR reg_date LIKE '%$search%'";
}

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Fullname</th>
                <th>Dob</th>
                <th>Gender</th>
                <th>Address</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Farmsize</th>
                <th>Bank Account</th>
                <th>Reg Date</th>
                <th>Actions</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . htmlspecialchars($row['fullname']) . "</td>
                <td>" . htmlspecialchars($row['dob']) . "</td>
                <td>" . htmlspecialchars($row['gender']) . "</td>
                <td>" . htmlspecialchars($row['address']) . "</td>
                <td>" . htmlspecialchars($row['email']) . "</td>
                <td>" . htmlspecialchars($row['mobile']) . "</td>
                <td>" . htmlspecialchars($row['farmsize']) . "</td>
                <td>" . htmlspecialchars($row['bank_account']) . "</td>
                <td>" . htmlspecialchars($row['reg_date']) . "</td>
                <td>
                    <a href='edituser.php?id=" . $row['id'] . "'>Edit</a> | 
                    <a href='?delete_user=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this user?\")'>Delete</a>
                </td>
            </tr>";
    }
    echo "</table>";
} else {
    echo "<div class='ticket-database-container'><h3>No users found</h3></div>";
}

if (isset($_GET['delete_user'])) {
    $user_id = intval($_GET['delete_user']);

    $delete_query = "DELETE FROM farmers WHERE id = ?";
    if ($stmt = $conn->prepare($delete_query)) {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            echo "<script>
                    alert('User deleted successfully!');
                    window.location.href = 'viewusers.php';  // Reload the page to reflect the change
                  </script>";
        } else {
            echo "<script>alert('Error deleting user.'); window.history.back();</script>";
        }
        $stmt->close();
    }
}

$conn->close();
?>
</div>
</body>
</html>
