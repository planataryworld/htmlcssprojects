

<?php
session_start();
include 'connection.php'; 

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $product_name = $_POST['product-name'] ?? '';
    $product_price = $_POST['product-price'] ?? '';
    $product_discount = $_POST['product-discount'] ?? '';
    $product_description = $_POST['product-description'] ?? '';
    $product_dimensions = $_POST['product-dimensions'] ?? '';
    $uploaded_image_path = '';

    if (empty($product_name) || empty($product_price) || empty($product_description)) {
        $errors[] = "Product Name, Price, and Description are required.";
    }

    $stmt = $conn->prepare("SELECT * FROM addservices WHERE productname = ?");
    $stmt->bind_param("s", $product_name);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $errors[] = "Product name already exists.";
    }
    $stmt->close();

    if (empty($errors)) {
        $sql = "INSERT INTO addservices (productname, price, discount, productdescription, dimensions, images) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $product_name, $product_price, $product_discount, $product_description, $product_dimensions, $uploaded_image_path);

        if ($stmt->execute()) {
            echo "<script>alert('Product added successfully');</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
        $stmt->close();
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<div style='color: red;'>$error</div>";
        }
    }
 
    
   
}


$result = $conn->query("SELECT * FROM addservices");


?>
<?php
if (!isset($_SESSION['email'])) {  
    header("Location:index.php");
    exit();
}

$user_Id = $_SESSION['email'];

$sqlQuery = "SELECT * FROM admindata WHERE email='$user_Id'";
$getResult = mysqli_query($conn, $sqlQuery);

if (!$getResult) {
    echo "<script>alert('Error fetching user data.');</script>";
    exit();
    }

$rowData = mysqli_fetch_assoc($getResult);
$storedDataName = $rowData['name'];
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(192, 187, 187); 
        }

        .container {
            padding: 20px;
        }

        .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 300px;
        }

        .toolbar {
            display: flex;
            width: 47%;
            justify-content: end;
            align-items: flex-end;
            flex-direction: row;
            gap: 45px;
            padding: 10px;
            background-color: rgb(192, 187, 187);
            border-radius: 8px;
            margin-top: 20px;
            margin-left: 780px;
        }

        .sort {
            display: flex;
            align-items: center;
            color: #333;
            cursor: pointer;
           
            margin-bottom: 11px;
        }

        .filter-icon {
            font-size: 16px;
            margin-right: 4px;
        }

        .search-container {
            flex-grow: 1;
            display: flex;
        }

        .search-bar {
            width: 250px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
        }

        .search-bar::placeholder {
            color: #aaa;
        }

        .cancel {
            color: #e74c3c;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
            padding: 8px;
        }

        .add-product {
            background-color: #e74c3c;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            width: 15vw;
            height: 5vh;
        }

        .add-product:hover {
            background-color: #c0392b;
        }

        .header {
            background-color: #E74C3C;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        .add-product-btn {
            margin: 20px;
            background-color: #E74C3C;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .add-product-btn:hover {
            opacity: 0.8;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #c0392b; 
            color: white;
            padding: 10px 20px;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .close-btn {
            color: white;
            font-size: 24px;
            cursor: pointer;
        }

        .form-row {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column; 
        }

        .form-row label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        .input-container {
            display: flex;
            align-items: center;
        }

        .input-container i {
            margin-right: 10px;
            font-size: 18px;
            color: #2980B9;
        }

        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #CCC;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-cancel {
            background-color: #E74C3C;
        }

        .btn-save {
            background-color: #2980B9;
        }

        .btn:hover {
            opacity: 0.8;
        }

         
.student-database-container {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    margin: 20px auto;
    width: 75%;
    background-color: #f9f9f9;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 10px;
    margin-left: 340px;
}


.student-database-container h3 {
    color: #5B3D7F;
    text-align: center;
    font-size: 22px;
    margin-bottom: 10px;
}

.student-database-container table {
    width: 100%;
    border-collapse: collapse;
    background-color: #ffffff;
}

.student-database-container th {
    text-align: left;
    font-weight: bold;
    color: #ff5252; 
    padding: 10px;
    border-bottom: 2px solid #e0e0e0;
    font-size: 16px;
    text-transform: lowercase;
}

.student-database-container td {
    color: #333;
    padding: 10px;
    border-bottom: 1px solid #e0e0e0;
    font-size: 14px;
    text-align: left;
}

.student-database-container tr:nth-child(even) {
    background-color: #f5f5f5; 
}

.student-database-container tr:last-child td {
    border-bottom: none; 
}

.student-database-container td[colspan="5"] {
    text-align: center;
    font-weight: bold;
    color: #ff5252;
}

    </style>
    
    <?php
    include 'adminproducts.php';
    ?> 
</head>
<body>
<script src="adminproductmain.js"></script>
    <div class="container">
        <div class="description">
            
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
        
                if (isset($_SESSION['email'])) {
                     echo "<span class='username'> " . htmlspecialchars($storedDataName) . "</span>";
                }
                ?>!</p>
                <p>Add, edit, remove and list Services here</p>
        </div>

        <div class="toolbar">
            <div class="sort">
                <i class="fa-solid fa-filter"></i>&nbsp;&nbsp;
                <span>Sort</span>
            </div>

            <div class="search-container">
                <input type="text" class="search-bar" placeholder="Search">&nbsp;&nbsp;&nbsp;
                <span class="cancel">Cancel</span>
            </div>

            <button class="add-product" id="openModalBtn">+ Add New Services</button>
        </div>
    </div>

    <div class="modal" id="productModal">
    <form name="form1" id="productForm"    method="post" enctype="multipart/form-data" onsubmit="return validateProductForm()">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Product</h2>
                <button class="close-btn" id="closeModalBtn">&times;</button>
            </div>

            <div class="form-row">
                <label for="product-name">Product Name</label>
                <div class="input-container">
                    <i class="fa-solid fa-couch"></i>
                    <input type="text" id="product-name" name="product-name" placeholder="Enter product name">
                </div>
            </div>

            <div class="form-row">
                <label for="product-price">Price</label>
                <div class="input-container">
                <i class="fa-solid fa-indian-rupee-sign"></i>
                <input type="text" id="product-price" name="product-price" placeholder="Enter product price">
                </div>
            </div>

            <div class="form-row">
                <label for="product-discount">Discount (%)</label>
                <div class="input-container">
                    <i class="fa-solid fa-tag"></i>
                    <input type="text" id="product-discount" name="product-discount" placeholder="Enter discount percentage">
                </div>
            </div>

            <div class="form-row">
                <label for="product-description">Product Description</label>
                <textarea id="product-description" rows="4" name="product-description" placeholder="Write a description for the product..."></textarea>
            </div>

            <div class="form-row">
                <label for="product-dimensions">Dimensions</label>
                <div class="input-container">
                    <i class="fa-solid fa-ruler-combined"></i>
                    <input type="text" id="product-dimensions" name="product-dimensions" placeholder="E.g., 120cm x 80cm x 40cm">
                </div>
            </div>

            <div class="form-row">
                <label for="product-images">Upload Product Images</label>
                <input type="file" id="product-images" name="product-images" accept=".jpg, .jpeg, .png">
            </div>

            <div class="button-container">
                <button class="btn btn-cancel" id="closeModalBtn2">CANCEL</button>
                
                <button class="btn btn-save" type="submit">SAVE</button> 
            </div>
        </div>
        </form>
    </div>

     

    <div class="student-database-container">
    <h3>User Information</h3>
    <table>
        <thead>
            <tr>
                      <th>ID</th>
                    <th>Product Name</th>
                    <th>Price(lakhs)</th>
                    <th>Discount</th>
                    <th>Description</th>
                    <th>Dimensions</th>
                    <th>Image</th>
            </tr>
        </thead>
        <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['productname']) ?></td>
                            <td><?= htmlspecialchars($row['price']) ?></td>
                            <td><?= htmlspecialchars($row['discount']) ?>%</td>
                            <td><?= htmlspecialchars($row['productdescription']) ?></td>
                            <td><?= htmlspecialchars($row['dimensions']) ?></td>
                            <td>
                                <?php if ($row['images']): ?>
                                    <img src="<?= htmlspecialchars($row['images']) ?>" alt="Service Image" width="100">
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No services available</td>
                    </tr>
                <?php endif; ?>
            </tbody>
    </table>
</div>






    <script>
        const modal = document.getElementById("productModal");
        const openModalBtn = document.getElementById("openModalBtn");
        const closeModalBtns = document.querySelectorAll("#closeModalBtn, #closeModalBtn2");

        openModalBtn.addEventListener("click", () => {
            modal.style.display = "flex";
        });

        closeModalBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                modal.style.display = "none";
            });
        });
    </script>
</body>
</html>
