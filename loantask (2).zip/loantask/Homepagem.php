<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-HomePage</title>
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>


</style>
<body>
    <script src="validations.js"></script>
    <div> 
        <?php include 'h.php'; ?>

        <section class="mainbody">
            <section class="mainbody1">    
                <h2><u>Welcome To. </u></h2>
                <div class="bodypart1">
                    <p> Welcome to,The Job Portal Resume Processing System is an intranet application for department of computer science for automating the process of resume preparation
            & applying for jobs.This would be facilitating the students & experienced candidates to make and pringt their resumes in a proper format.In, addition,it will be facilitating the higher
            management to search depending upon their skill sets and other attributes.

        </p>
        <p>
         The basic is to recruitement is to have a contributed respository of all skill-holders in the organisations and students with a particular
        skill set can immediately found in the case of urgent requirement. And also searching for jobs and applying for jobs is possible.
        </p>

        <p>
        Job portal websites serve as a bridge between employers and job seekers, streamlining the recruitment and job application process. They are platforms designed to connect individuals seeking employment with companies looking to hire, 
        offering a wide array of tools and services for both parties.
        </p>
                </div>
                <h2><u>Short_Term_Agriculture_Loan. </u></h2>
                <div class="bodypart1">
                    <p> The Kisan Credit Card scheme aims at providing adequate and timely credit support from the banking system under a single window with flexible and simplified procedure to the farmers for their cultivation and other needs as indicated below:

      To meet the short term credit requirements for cultivation of crops;
Post-harvest expenses;
Produce marketing loan;
Consumption requirements of farmer household;
Working capital for maintenance of farm assets and activities allied to agriculture; Interest Rate :7.0%</p>
</div>

<h2><u>krishi-mitra-card-scheme. </u></h2>
                <div class="bodypart1">
                    <p> It is an exclusive credit card scheme for individual tenant farmers and farmers without proper land records. It is used for financing the following :

Cultivation of crops
Post-harvest /household /consumption requirement
Repairs and maintenance expenses of farm assets.
Crop insurance.Interest Rate :7.5% </p></div>

<h2><u>farm-machinery-loans. </u></h2>
                <div class="bodypart1">
                    <p> Farm machinery loans are considered for purchase of tractor, power tiller, trailer and accessories, combine harvester, grain threshers,sprayers, dusters, ploughs drills and such other farm implements and equipments needed for agricultural activity.
It is to be ensure that the HP of the tractor to be purchased suits the soil, cropping pattern, size of land holding of the applicant.
Further, only such Tractors/ Power Tillers, combine harvesters which are in our approved list, are to be financed. Interest Rate :8.5%</p></div>


<h2><u>Dairy-Loans. </u></h2>
                <div class="bodypart1">
                    <p> Construction of cattle shed
Purchase of high yielding milch cattle (yielding not less than 5 litres per day)
Purchase of dairy equipments, cattle feed and for cultivation of green fodder.
Expenditure incurred for transportation of animals where the animals are not purchased locally.
Initial feed cost for a period of 1 month at the rate of 120 kgs. per animal for the first batch of animals.
Setting up of on farm processing and pasteurization plants.
Loans can be extended for purchase of Crossbred heifer and/or for its rearing till it reaches lactation period.
Known cattle breeders and technically qualified entrepreneurs can be financed for purchase of non descript cows for getting crossbred progeny and for its rearing upto maturity or till it is sold, whichever is earlier.Interest Rate :11.0% </p></div>

            </section>
            
           
    </div>


<a href="#"class="scroll-to-top" id="scrollToTopBtn" title="Scroll to top"><i class="fas fa-arrow-up"></i></a>

<div class="button-container">
  
    <a href="https://wa.me/1234567890" class="whatsapp-button" target="_blank">
        <i class="fab fa-whatsapp"></i> WhatsApp us
    </a>
</div>

<div id="disclaimerModal">
        <div id="disclaimerModalContent">
            <h2>Disclaimer</h2>
            <p>By continuing, you agree to our terms and conditions. Please confirm to proceed.</p>
            <button id="agreeButton">I Agree</button>
            <button id="disagreeButton">I Disagree</button>
        </div>
    </div>

<script>
  const scrollToTopBtn = document.getElementById('scrollToTopBtn');

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    scrollToTopBtn.style.display = 'block'; 
  } else {
    scrollToTopBtn.style.display = 'none'; 
  }
});


scrollToTopBtn.addEventListener('click', (e) => {
  e.preventDefault();
  window.scrollTo({
    top: 0,
    behavior: 'smooth' 
  });
});
</script>

<script>
    (function(d, w, c) {
        w.ChatraID = 'Z3tkRZ7XYPdwa8643';
        var s = d.createElement('script');
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        s.async = true;
        s.src = 'https://call.chatra.io/chatra.js';
        if (d.head) d.head.appendChild(s);
    })(document, window, 'Chatra');
</script>

<script>
     
     const modal = document.getElementById('disclaimerModal');
        const agreeButton = document.getElementById('agreeButton');
        const disagreeButton = document.getElementById('disagreeButton');

      
        window.onload = function() {
            modal.style.display = 'block';
        };

        
        agreeButton.onclick = function() {
            modal.style.display = 'none';
           
        };

       
        disagreeButton.onclick = function() {
            window.location.href = 'https://www.google.com';
        };
</script>
</body>
</html>