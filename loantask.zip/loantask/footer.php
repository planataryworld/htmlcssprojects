
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            color: #333;
        }
        .background {
            padding: 0;
            margin: 0;
        }
        .pump {
            width: 100%;
           
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border: 1px solid #ccc;
            background-color: rgb(192, 223, 242);
            padding: 20px;
            border-radius: 2px;
        }
        .pump1 h1 {
            margin-bottom: 10px;
            padding: 10px;
            background-color: #ffffff;
            box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
            border-radius: 5px;
        }
        .pump6 p {
            margin-top: 20px;
            font-weight: bold;
        }
        .pump7 i {
            margin: 10px 15px 0 0;
            display: inline-block;
            font-size: 24px;
            color: #333;
        }
        .pump7 i:hover {
            color: #007BFF;
            cursor: pointer;
        }
        .pump2, .pump3, .pump4 {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .pump2 p, .pump3 p, .pump4 p {
            cursor: pointer;
            margin-bottom: 5px;
            color: #333;
            text-decoration: none;
        }
        .pump2 p:hover, .pump3 p:hover, .pump4 p:hover {
            color: #007BFF;
            text-decoration: underline;
        }
        .pump5 img {
            width: 100%;
            max-width: 150px;
            height: auto;
            border-radius: 5px;
        }
        
    </style>
</head>
<body>
    <div class="background">
        <div class="pump">
            <div class="pump1">
                <h1>Canara Bank</h1>
                <div class="pump6">
                    <p>Connect with us</p>
                </div>
                <div class="pump7">
                <a href="https://www.facebook.com/" target="_blank" title="Facebook">
        <i class="fab fa-facebook"></i>
    </a>
    <a href="https://www.instagram.com/" target="_blank" title="Instagram">
        <i class="fab fa-instagram"></i>
    </a>
    <a href="https://x.com/?lang=en" target="_blank" title="Twitter">
        <i class="fab fa-twitter"></i>
    </a>
    <a href="https://www.whatsapp.com/" target="_blank" title="WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>
                </div>
            </div>
            <div class="pump2">
                <p>About Us</p>
                <p>Employer Home</p>
                <p>Careers</p>
            </div>
            <div class="pump3">
                <p>Help Center</p>
                <p>Summons/Notices</p>
                <p>Report Issue</p>
            </div>
            <div class="pump4">
                <p>Privacy Policy</p>
                <p>Terms & Conditions</p>
                <p>Fraud Alert</p>
            </div>
            <div class="pump5">
                <img src="https://www.techgrapple.com/wp-content/uploads/2016/06/Google-Play-and-App-Store.jpg" alt="App Store and Google Play">
            </div>
        </div>
    </div>
</body>

