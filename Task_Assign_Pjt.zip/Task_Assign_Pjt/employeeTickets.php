<?php 
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(192, 187, 187); 
        }

        .container {
            padding: 20px;
        }

        .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 300px;
        }

        .student-database-container {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            margin: 20px auto;
            width: 75%;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 10px;
            margin-left: 340px;
        }

        .student-database-container h3 {
            color: #5B3D7F;
            text-align: center;
            font-size: 22px;
            margin-bottom: 10px;
        }

        .student-database-container table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
        }

        .student-database-container th {
            text-align: left;
            font-weight: bold;
            color: #ff5252; 
            padding: 10px;
            border-bottom: 2px solid #e0e0e0;
            font-size: 16px;
            text-transform: lowercase;
        }

        .student-database-container td {
            color: #333;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
            text-align: left;
        }

        .student-database-container tr:nth-child(even) {
            background-color: #f5f5f5;
        }

        .student-database-container tr:last-child td {
            border-bottom: none;
        }

        .student-database-container td[colspan="5"] {
            text-align: center;
            font-weight: bold;
            color: #ff5252;
        }

    </style>
    
    <?php 
    include 'sidenav2.php';
    ?>
</head>
<body>
<script src="adminproductmain.js"></script>
    <div class="container">
        <div class="description">
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
                
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
        </div>
    </div>
    <div class="student-database-container">
    <h3>Open Tickets Info</h3>
    <table>
         <tbody>

         <?php
include 'connection.php';
session_start();

if (!isset($_SESSION['full_name'])) {
    echo "<script>alert('Error: User full name not set in session.'); window.history.back();</script>";
    exit();
}

$full_name = $_SESSION['full_name'];


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['ticket_id']) && isset($_POST['action'])) {
        $ticket_id = $_POST['ticket_id'];
        $action = $_POST['action'];

    
        if ($action == 'in_progress') {
            $new_status = 'in_progress';
          
            $update_stmt = $conn->prepare("UPDATE tickets SET status = ? WHERE id = ?");
            $update_stmt->bind_param("si", $new_status, $ticket_id);
            if ($update_stmt->execute()) {
                echo "<script type='text/javascript'>alert('Ticket status updated to In Progress');</script>";
            } else {
                echo "<script type='text/javascript'>alert('Error updating ticket status');</script>";
            }
            $update_stmt->close();
        } elseif ($action == 'reject') {
            $new_status = 'Rejected';
           
            $update_stmt = $conn->prepare("UPDATE tickets SET status = ? WHERE id = ?");
            $update_stmt->bind_param("si", $new_status, $ticket_id);
            if ($update_stmt->execute()) {
                echo "<script type='text/javascript'>alert('Ticket status updated to Rejected');</script>";
            } else {
                echo "<script type='text/javascript'>alert('Error updating ticket status');</script>";
            }
            $update_stmt->close();
        }
    }
}

$query = "SELECT t.id, t.title, t.description, t.priority, t.status, t.created_at 
          FROM tickets t
          LEFT JOIN users u ON t.assigned_to = u.id
          WHERE t.status = 'open' AND CONCAT(u.firstname, ' ', u.lastname) = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $full_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>Ticket ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Priority</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . htmlspecialchars($row['title']) . "</td>
                <td>" . htmlspecialchars($row['description']) . "</td>
                <td>" . ucfirst($row['priority']) . "</td>
                <td>" . ucfirst($row['status']) . "</td>
                <td>" . $row['created_at'] . "</td>
                <td>
                    <form method='post' action=''>
                        <input type='hidden' name='ticket_id' value='" . $row['id'] . "'>
                        <button type='submit' name='action' value='in_progress'>In Progress</button>
                        <button type='submit' name='action' value='reject'>Reject</button>
                    </form>
                </td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<div class='student-database-container'><h3>No tickets found</h3></div>";
}


$stmt->close();
$conn->close();
?>
            </tbody>
    </table>
</div>

</body>
</html>
