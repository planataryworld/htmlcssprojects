<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $domain = $_POST['domain'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $skills = $_POST['skills'];

    // Hash the password securely
    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, phonenumber, domine, email, password, skills) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $first_name, $last_name, $phone, $domain, $email, $password_hashed, $skills);

    // Execute the statement and show popup
    if ($stmt->execute()) {
        echo "<script>
                alert('User registered successfully!');
                window.location.href = 'index.php'; // Redirect to the form after alert
              </script>";
    } else {
        echo "<script>
                alert('Error: " . $stmt->error . "');
                window.location.href = 'register_form.php'; // Redirect to the form after alert
              </script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4p889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #1e1e2f, #49336d);
            height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #fff;
        }

        .header {
            position: sticky; /* Makes the header sticky */
            top: 0; /* Sticky to the top */
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            width: 100%;
            padding: 20px 30px;
            background: rgba(0, 0, 0, 0.7);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            z-index: 10; /* Ensure it's on top of other content */
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 28px;
            font-weight: bold;
            font-family: 'Playfair Display', serif;
            color: #ffcc00;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .logo span {
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            padding: 40px;
            width: 560px;
            box-shadow: 0px 4px 30px rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(10px);
            text-align: center;
            margin-top: 50px;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .form-container .avatar {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            height: 80px;
            width: 80px;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 36px;
        }

        .form-container h2 {
            margin: 20px 0;
            font-size: 26px;
            font-weight: bold;
            color: #fff;
        }

        .form-container label {
            display: block;
            text-align: left;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-container input,
        .form-container select,
        .form-container button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
        }

        .form-container input,
        .form-container select {
            background: rgba(255, 255, 255, 0.2);
            
        }

        .form-container input::placeholder {
            color: #aaa;
        }

        .form-container input:focus,
        .form-container select:focus {
            outline: none;
            background: rgba(255, 255, 255, 0.3);
        }

        .form-container .button-group {
            /* background: linear-gradient(90deg, #6a5acd, #483d8b); */
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
            border-radius: 10px;
        }

        .form-container button:hover {
            background: linear-gradient(90deg, #483d8b, #6a5acd);
        }

        .form-container .error-message {
            color: #ff6f61;
            font-size: 14px;
            margin-top: 10px;
        }
        .form-container .button-group button {
            width: 48%;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <i class="fas fa-building"></i>
            <span>JMJ Company</span>
        </div>
    </div>

    <div class="form-container">
        <div class="avatar">
            <i class="fas fa-user"></i>
        </div>
        <h2>Employee Register Here</h2>
        <form name="userregis" method="POST" onsubmit="return validateForm()">
            <label for="first_name">First Name:</label>
            <input type="text" id="first_name" name="first_name" placeholder="Enter your first name" required>
            
            <label for="last_name">Last Name:</label>
            <input type="text" id="last_name" name="last_name" placeholder="Enter your last name" required>
            
            <label for="phone">Phone Number:</label>
            <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" pattern="[0-9]{10}" required>

            <label for="domain">Domain:</label>
            <select id="domain" name="domain" required>
                <option value="">---------select one----------</option>
                <option value="Web Developer">Web Developer</option>
                <option value="Tester">Tester</option>
                <option value="Application Developer">Application Developer</option>
                <option value="Intern">Intern</option>
                <option value="Software Developer">Software Developer</option>
            </select>
            
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email address" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>
            
            <label for="skills">Skills (comma-separated):</label>
            <input type="text" id="skills" name="skills" placeholder="e.g., PHP, JavaScript, SQL" required>
            
            <div class="button-group">
                <button type="submit">Register</button>
                <button type="button" onclick="window.location.href='index.php'">Login</button>
            </div>
        </form>
    </div>
</body>
</html>
