<?php
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
        font-family: Arial, sans-serif;
        background: #ff4d4d;
        margin: 0;
      }

      .container {
        padding: 20px;
        text-align: center;
      }

      .description p {
            font-size: 18px;
            color: white;
            margin: 0;
            margin-left: 900px;
          
        }
      .student-database-container {
        width: 110%;
        max-width: 1250px;
        background: #fff;
        margin: 20px auto;
        padding: 10px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-left: 220px;
      }

      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }

      table, th, td {
        border: 1px solid #ddd;
        padding: 5px;
        text-align: left;
        color: black;
        font-size: 13px;
      }

      th {
        background-color: #f2f2f2;
      }

      tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      .search-box {
        text-align: center;
        margin-bottom: 10px;
      }
    </style>
</head>
<body>
<?php include 'sidenav2.php'; ?>
    <div class="container">
        <h3>Approved Loan Applications</h3>
        <div class="search-box">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search loans...">
                <button type="submit">Search</button>
            </form>
        </div>
    </div>

    <div class="student-database-container">
        <?php
        $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
        $query = "SELECT id, purpose_of_loan, loan_amount, repayment_period,  fullname, telephone, status, approved_loan_amount, interestrate FROM loanapplication";
        if ($search) {
            $query .= " WHERE purpose_of_loan LIKE '%$search%' OR fullname LIKE '%$search%'";
        }
        $result = $conn->query($query);
        if ($result && $result->num_rows > 0) {
            echo "<table>
                    <tr>
                        <th>ID</th><th>Purpose</th><th>Amount</th><th>Period</th><th>Name</th>
                        <th>Phone</th><th>Status</th><th>Approved Amount</th><th>Interest Rate (%)</th><th>Total</th><th>Actions</th>
                    </tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['purpose_of_loan']}</td>
                        <td>{$row['loan_amount']}</td>
                        <td>{$row['repayment_period']}</td>
                       
                        <td>{$row['fullname']}</td>
                        <td>{$row['telephone']}</td>
                        <td>{$row['status']}</td>
                        <td><input type='number' id='approved_loan_{$row['id']}' value='{$row['approved_loan_amount']}' oninput='calculateTotal({$row['id']})'></td>
                        <td><input type='number' id='interest_{$row['id']}' value='{$row['interestrate']}' oninput='calculateTotal({$row['id']})'></td>
                        <td id='total_{$row['id']}'>0.00</td>
                        <td>
                            <button onclick='updateLoan({$row['id']})'>Update</button>
                            <button onclick='deleteLoan({$row['id']})'>Delete</button>
                            <button onclick='approveLoan({$row['id']})'>Approve</button>
                           <button onclick='rejectLoan({$row['id']})'>Reject</button>
                        </td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No loan applications found.</p>";
        }
        ?>
    </div>

    <script>
    function calculateTotal(id) {
        let approvedAmount = parseFloat(document.getElementById('approved_loan_' + id).value) || 0;
        let interestRate = parseFloat(document.getElementById('interest_' + id).value) || 0;
        let totalAmount = approvedAmount + (approvedAmount * interestRate / 100);
        document.getElementById('total_' + id).innerText = totalAmount.toFixed(2);
    }

    function updateLoan(id) {
        let approvedAmount = document.getElementById('approved_loan_' + id).value;
        let interestRate = document.getElementById('interest_' + id).value;

        let xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_loan.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                alert('Loan updated successfully!');
            }
        };
        xhr.send('id=' + id + '&approved_loan_amount=' + approvedAmount + '&interestrate=' + interestRate);
    }

    function deleteLoan(id) {
        if (confirm('Are you sure you want to delete this loan?')) {
            let xhr = new XMLHttpRequest();
            xhr.open('POST', 'delete_loan.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    alert('Loan deleted successfully!');
                    location.reload();
                }
            };
            xhr.send('id=' + id);
        }
    }


    function approveLoan(id) {
    let totalAmount = document.getElementById('total_' + id).innerText;
    
    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_loan.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            alert('Loan Approved Successfully!');
            location.reload();
        }
    };
    xhr.send('id=' + id + '&approved_loan_amount=' + totalAmount + '&status=Approved');
}

function rejectLoan(id) {
    let xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_loan.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            alert('Loan Rejected!');
            location.reload();
        }
    };
    xhr.send('id=' + id + '&approved_loan_amount=0&status=Rejected');
}
    </script>
</body>
</html>
