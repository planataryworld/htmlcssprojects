<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $fullname = trim($_POST['fullname'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $gender = trim($_POST['gender'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $security_question = trim($_POST['security-question'] ?? '');
    $answer = trim($_POST['answer'] ?? '');
    $farmsize = trim($_POST['farmsize'] ?? '');
    $crops = trim($_POST['crops'] ?? '');
    $bank_account = trim($_POST['bank-account'] ?? '');

  
    

    
    $sql = "SELECT * FROM farmers WHERE email = ? OR mobile = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $mobile);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        if ($user['email'] === $email) {
            echo "<script>alert('Email already exists.');</script>";
        } elseif ($user['mobile'] === $mobile) {
            echo "<script>alert('Mobile number already exists.');</script>";
        }
    } else {
       
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

       
        $sql1 = "INSERT INTO farmers (fullname, dob, gender, address, city, email, mobile, password, security_question, answer, farmsize, crops, bank_account) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql1);
        $stmt->bind_param("sssssssssssss", $fullname, $dob, $gender, $address, $city, $email, $mobile, $hashed_password, $security_question, $answer, $farmsize, $crops, $bank_account);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful');
            window.location.href='usersign.php'</script>";
        } else {
            echo "<script>alert('An error occurred. Please try again.');</script>";
        }
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-UsersSign</title>
    
    <link rel="stylesheet" href="usersign.css">
</head>
<script>
        function validateUserRegistration() {
            var fullname = document.getElementById('fullname').value.trim();
            var dob = document.getElementById('dob').value.trim();
            var gender = document.getElementById('gender').value.trim();
            var address = document.getElementById('address').value.trim();
            var city = document.getElementById('city').value.trim();
            var email = document.getElementById('email').value.trim();
            var mobile = document.getElementById('mobile').value.trim();
            var password = document.getElementById('password').value.trim();
            var securityQuestion = document.getElementById('security-question').value.trim();
            var answer = document.getElementById('answer').value.trim();
            var farmsize = document.getElementById('farmsize').value.trim();
            var crops = document.getElementById('crops').value.trim();
            var bankAccount = document.getElementById('bank-account').value.trim();

            if (fullname === '') {
                alert('Full Name is required');
                return false;
            }
            if (dob === '') {
                alert('Date of Birth is required');
                return false;
            }
            if (gender === '') {
                alert('Gender is required');
                return false;
            }
            if (address === '') {
                alert('Address is required');
                return false;
            }
            if (city === '') {
                alert('City is required');
                return false;
            }
            if (email === '') {
                alert('Email is required');
                return false;
            }
            if (!validateEmail(email)) {
                alert('Invalid email format');
                return false;
            }
            if (mobile === '') {
                alert('Mobile number is required');
                return false;
            }
            if (!validateMobile(mobile)) {
                alert('Invalid mobile number format');
                return false;
            }
            if (password === '') {
                alert('Password is required');
                return false;
            }
            if (securityQuestion === '') {
                alert('Security Question is required');
                return false;
            }
            if (answer === '') {
                alert('Answer is required');
                return false;
            }
            if (farmsize === '') {
                alert('Farm Size is required');
                return false;
            }
            if (isNaN(farmsize) || farmsize <= 0) {
                alert('Farm Size must be a positive number');
                return false;
            }
            if (crops === '') {
                alert('Type of Crops Grown is required');
                return false;
            }
            if (bankAccount === '') {
                alert('Bank Account Number is required');
                return false;
            }
            if (!validateBankAccount(bankAccount)) {
                alert('Invalid Bank Account Number format');
                return false;
            }

            return true;
        }

        function validateEmail(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }

        function validateMobile(mobile) {
            var re = /^[0-9]{10}$/;
            return re.test(mobile);
        }

        function validateBankAccount(bankAccount) {
            var re = /^[0-9]{9,13}$/;
            return re.test(bankAccount);
        }
    </script>
<body>
    <script src="usersign.js"></script>
    <div>
    <?php include 'h.php'; ?>

    <div class="mainbody">
        <div class="mainbody1">
            <h2><u>User Registration Form. </u></h2>
            <div class="signin-section ptb-100">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-8 offset-md-2 offset-lg-3">
                            <form name="form1" method="post" onsubmit="return validateUserRegistration()">
                                <div class="form-group">
                                    <label for="fullname">Full Name:</label>
                                    <input type="text" id="fullname" name="fullname">
                                </div>
                                <div class="form-group">
                                    <label for="dob">Date of Birth:</label>
                                    <input type="date" id="dob" name="dob">
                                </div>
                                <div class="form-group">
                                    <label for="gender">Gender:</label>
                                    <select id="gender" name="gender">
                                        <option value="">Select</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="address">Address:</label>
                                    <textarea id="address" name="address" rows="3"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="city">City:</label>
                                    <input type="text" id="city" name="city">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email:</label>
                                    <input type="email" id="email" name="email">
                                </div>
                                <div class="form-group">
                                    <label for="mobile">Mobile:</label>
                                    <input type="tel" id="mobile" name="mobile">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password:</label>
                                    <input type="password" id="password" name="password">
                                </div>
                                <div class="form-group">
                                    <label for="security-question">Security Question:</label>
                                    <select id="security-question" name="security-question">
                                        <option value="">Select</option>
                                        <option value="favourite-fruit">What is Your Favourite Fruit?</option>
                                        <option value="favourite-color">What is Your Favourite Color?</option>
                                        <option value="pet-name">What is Your Pet's Name?</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="answer">Answer:</label>
                                    <input type="text" id="answer" name="answer">
                                </div>
                                <div class="form-group">
                                    <label for="farmsize">Farm Size (in acres):</label>
                                    <input type="text" id="farmsize" name="farmsize">
                                </div>
                                <div class="form-group">
                                    <label for="crops">Type of Crops Grown:</label>
                                    <select id="crops" name="crops">
                                        <option value="">Select</option>
                                        <option value="wheat">Wheat</option>
                                        <option value="rice">Rice</option>
                                        <option value="corn">Corn</option>
                                        <option value="soybeans">Soybeans</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="bank-account">Bank Account Number:</label>
                                    <input type="text" id="bank-account" name="bank-account">
                                </div>
                                <div class="form-group">
                                    <button type="submit">Register</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>