<?php

session_start();
include 'connection.php';



if (!isset($_SESSION['user_email'])) {
    header("Location: User_Login.php");
    exit();
}

$first_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : 'User';

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <style>
        body {
            margin: 0;
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to top, rgba(255, 255, 224, 0.8), rgba(255, 239, 179, 0.8));

            color: #333;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }


        .sidebar {
            width: 300px;
            background: url('https://img.freepik.com/free-vector/line-luxury-gradient-color-minimalist-style-wave_483537-3948.jpg?t=st=1737971366~exp=1737974966~hmac=7c4cb79414573a00994d18b367f33c2f618902498bbb1591e0b8f396437279eb&w=996') no-repeat center center;
            background-size: cover;
            color: #fff;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }

        .brand h1 {
            font-size: 1.8rem;
            text-align: center;
        
            margin-bottom: 20px;
            letter-spacing: 2px;
            color: white;
            text-shadow: 2px 2px 4px rgb(184, 38, 38);
        }


        .main {
            flex: 1;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 1.8rem;
            color: white;
        }

        .search {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 25px;
            width: 250px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #4e54c8;
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #3c3fab;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .stat-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            color: #333;
            width: 80%;
            height: 150px;
        }

        .stat-card h2 {
            font-size: 1.2rem;
            margin-bottom: 10px;
            color: White;
        }

        .stat-card p {
            font-size: 2rem;
            font-weight: bold;
        }

        .card-blue {
            background: linear-gradient(135deg, #4e54c8, #8f94fb);
            color: #fff;
        }

        .card-green {
            background: linear-gradient(135deg, #28a745, #81c784);
            color: #fff;
        }

        .card-purple {
            background: linear-gradient(135deg, #6f42c1, #c791e6);
            color: #fff;
        }

        .card-orange {
            background: linear-gradient(135deg, #ff7e31, #ffb56a);
            color: #fff;
        }

        /* Charts Section */
        .charts {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .chart-card {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .chart-card h3 {
            margin-bottom: 15px;
            font-size: 1.2rem;
            color: #555;
        }

        .menu {
            list-style: none;
            padding: 0;
            padding-top: 20px;
        }

        .menu li {
            margin: 15px 0;
        }

        .menu a {
            text-decoration: none;
            color: #fff;
            font-size: 1rem;
            padding: 10px 15px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .menu a.active,
        .menu a:hover {
            background-color: rgba(255, 255, 255, 0.2);
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: black;
            box-shadow: 0px 4px 6px rgba(248, 211, 211, 0.1);
            border-radius: 8px;
            list-style: none;
            padding: 0;
            margin: 0;
            z-index: 1000;
            width: 200px;
            opacity: 0;
            transform: translateY(-20px);
            transition: opacity 0.3s, transform 0.3s;
        }

        .dropdown-menu li {
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
        }

        .dropdown-menu li a {
            text-decoration: none;
            color: white;
            display: block;
        }

        .dropdown-menu li a:hover {
            background-color: #f0f0f0;
            color: #000;
        }

        .dropdown:hover .dropdown-menu {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }

        .assigned-tickets {
            transition: margin-top 0.3s ease;
        }

        .dropdown.open+.assigned-tickets {
            margin-top: 380px;
            
        }

        .dropdown-toggle i {
            margin-left: 25px;
            color: white;
        }

        .main {
            flex: 1;
            padding: 20px;
            position: relative;
            background: url('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGUSJos615Hr_lBpuCjvBFLJbG78uW4g9sJQ&s') no-repeat center center;
            background-size: cover;
            color: white;
        }


        .main::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            z-index: 0;
        }


        .main>* {
            position: relative;
            z-index: 1;
        }

        .welcome-message {
            margin-top: -20px;
            font-size: 25px;
            color: orange;
            margin-bottom: 50px;
        }

        .user-data {
            margin: 20px 0;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow-x: scroll;

        }

        .user-data h2 {
            font-size: 1.8rem;
            margin-bottom: 15px;
            color: #4e54c8;
            text-align: center;
            text-transform: uppercase;
            font-weight: bold;
        }

        .user-data table {
            width: 200%;
            border-collapse: collapse;
            min-width: 1000px;
         
            overflow-x: scroll;
        }

        .user-data th,
        .user-data td {
            padding: 12px 15px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .user-data th {
            background-color: #4e54c8;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9rem;
        }

        .user-data tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .user-data tr:nth-child(odd) {
            background-color: #ffffff;
        }

        .user-data tr:hover {
            background-color: #f1f1f1;
        }

        .user-data td a {
            text-decoration: none;
            font-weight: bold;
            color: #4e54c8;
            transition: color 0.3s;
        }

        .user-data td a:hover {
            color: #2f3788;
            text-decoration: underline;
        }

        .user-data td {
            font-size: 0.9rem;
            color: #333;
        }

      
        .user-data-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        @media screen and (max-width: 768px) {
            .user-data table {
                font-size: 0.85rem;
            }

            .user-data th,
            .user-data td {
                padding: 10px;
            }
        }
    </style>
</head>

<body>
    <div class="dashboard">
       
        <nav class="sidebar">
            <div class="brand">
                <h1>BSIT SOFTWARE SERVICES</h1>
            </div>
            <ul class="menu">
                <li><a href="#"><i class="fa-solid fa-house"></i>&emsp; DASHBOARD</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle"><i class="fa-solid fa-ticket" style="margin-left: 0;"></i>&emsp;MY TICKETS<i class="fas fa-caret-down" style="color: white;"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">ALL TICKETS</a></li>
                        <li><a href="#">OPEN TICKETS</a></li>
                        <li><a href="#">IN PROGRESS</a></li>
                        <li><a href="#">COMPLETED</a></li>
                        <li><a href="#">HIGH PRIORITY</a></li>
                    </ul>
                </li>
                <li class="assigned-tickets"><a href="#"><i class="fa-solid fa-clipboard-check"></i>&emsp; ASSIGNED TICKETS</a></li>
            </ul>
            </ul>
        </nav>

        <main class="main">
            
            <header class="header">
                <h1>DASHBOARD OVERVIEW</h1>
                <div class="header-actions">
                    <input type="text" placeholder="Search..." class="search">
                    <button class="btn"> <a href="User_Logout.php" style="color: white; text-decoration:none; font-size:16px;">Log Out</a></button>
                </div>
            </header>

           
            <div class="welcome-message">
                Welcome, <?php echo htmlspecialchars($first_name); ?>!
            </div>

            <div class="user-data">
                <h2>Your Assigned Tickets</h2>
                <table border="1" style="width: 100%; text-align: left; border-collapse: collapse; background-color: white; color: black;">
                    <thead>
                        <tr style="background-color: #4e54c8; color: white;">
                            <th>Ticket ID</th>
                            <th>Description</th>
                            <th>Priority</th>
                            <th>Email</th>
                            <th>Skills Required</th>
                            <th>File</th>
                            <th>Created at</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php

                    include 'dbconnection.php';
                      
                        $user_email = $_SESSION['user_email'];
                        
                        
                        $query = "SELECT ticket_id, description, priority_level, required_skills, user_email, file, created_at 
                                  FROM tickets
                                  WHERE assigned_to = ?";
                        $stmt = $conn->prepare($query);
                        $stmt->bind_param("s", $user_email);
                        $stmt->execute();
                        $result = $stmt->get_result();

                       
                        if ($result->num_rows > 0) {
                            while ($ticket = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . htmlspecialchars($ticket['ticket_id']) . "</td>
                                        <td>" . htmlspecialchars($ticket['description']) . "</td>
                                        <td>" . htmlspecialchars($ticket['priority_level']) . "</td>
                                        <td>" . htmlspecialchars($ticket['user_email']) . "</td>
                                        <td>" . htmlspecialchars($ticket['required_skills']) . "</td>
                                        <td>";
                                if (!empty($ticket['file'])) {
                                    echo "<a href='uploads/" . htmlspecialchars($ticket['file']) . "' download>Download</a>";
                                } else {
                                    echo "No file";
                                }
                                echo "</td>
                                        <td>" . htmlspecialchars($ticket['created_at']) . "</td>
                                    </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' style='text-align: center;'>No tickets assigned to you.</td></tr>";
                        }

                        $stmt->close();
                        ?>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>

</html>

<?php

$conn->close();
?>