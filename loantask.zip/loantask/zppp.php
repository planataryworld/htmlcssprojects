<?php
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
        font-family: Arial, sans-serif;
        background: #ff4d4d;
        margin: 0;
      }

      .container {
        padding: 20px;
        text-align: center;
      }

      .description p {
            font-size: 18px;
            color: white;
            margin: 0;
            margin-left: 900px;
          
        }
      .student-database-container {
        width: 110%;
        max-width: 1250px;
        background: #fff;
        margin: 20px auto;
        padding: 10px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-left: 220px;
      }

      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
      }

      table, th, td {
        border: 1px solid #ddd;
        padding: 5px;
        text-align: left;
        color: black;
        font-size: 13px;
      }

      th {
        background-color: #f2f2f2;
      }

      tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      .search-box {
        text-align: center;
        margin-bottom: 10px;
      }
    </style>
</head>
<body>
  <?php include 'sidenav2.php' ?>
    <div class="container">
        <div class="description">
            <p>Welcome back, <?php echo isset($_SESSION['full_name']) ? htmlspecialchars($_SESSION['full_name']) : ''; ?>!</p>
        </div>
    </div>

    <div class="student-database-container">
        <h3>Approved Loan Applications</h3>
        <div class="search-box">
            <form method="GET" action="">
                <input type="text" name="search" placeholder="Search loans..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <?php
        // Establish connection and fetch data
        $search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
        $query = "SELECT id, purpose_of_loan, loan_amount, repayment_period, location, fullname, telephone, status, approved_loan_amount, interestrate, (approved_loan_amount + (approved_loan_amount * interestrate / 100)) AS total_amount FROM loanapplication";

        if ($search) {
            $query .= " WHERE purpose_of_loan LIKE '%$search%' OR fullname LIKE '%$search%'";
        }

        // Execute the query
        $result = $conn->query($query);

        if ($result && $result->num_rows > 0) {
            echo "<form method='POST' action=''>
                    <table border='1'>
                    <tr>
                        <th>ID</th>
                        <th>Purpose of Loan</th>
                        <th>Loan Amount</th>
                        <th>Repayment Period</th>
                        <th>Location</th>
                        <th>Full Name</th>
                        <th>Telephone</th>
                        <th>Status</th>
                        <th>Approved Amount</th>
                        <th>Interest Rate (%)</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>";

            // Display loan applications
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>" . htmlspecialchars($row['purpose_of_loan']) . "</td>
                        <td>" . htmlspecialchars($row['loan_amount']) . "</td>
                        <td>" . htmlspecialchars($row['repayment_period']) . "</td>
                        <td>" . htmlspecialchars($row['location']) . "</td>
                        <td>" . htmlspecialchars($row['fullname']) . "</td>
                        <td>" . htmlspecialchars($row['telephone']) . "</td>
                        <td>" . htmlspecialchars($row['status']) . "</td>
                        <td>
                            <form method='POST' action=''>
                                <input type='hidden' name='loan_id' value='{$row['id']}'>
                                <input type='number' name='approved_loan_amount' value='" . htmlspecialchars($row['approved_loan_amount']) . "' step='0.01'>
                        </td>
                        <td>
                                <input type='number' name='interestrate' value='" . htmlspecialchars($row['interestrate']) . "' step='0.01'>
                        </td>
                        <td>" . htmlspecialchars($row['total_amount']) . "</td>
                        <td>
                                <button type='submit' name='update_single_loan'>Update</button>
                            </form>
                            <a href='?status=approved&id={$row['id']}'>Approve</a> | 
                            <a href='?status=rejected&id={$row['id']}'>Reject</a> | 
                            <button type='button' onclick='confirmDelete({$row['id']})'>Delete</button>
                        </td>
                      </tr>";
            }
            echo "</table></form>";
        } else {
            echo "<p>No loan applications found.</p>";
        }

        // Handle loan update
        if (isset($_POST['update_single_loan'])) {
            $id = $_POST['loan_id'];
            $approved_loan_amount = $_POST['approved_loan_amount'];
            $interestrate = $_POST['interestrate'];
            
            // Calculate Total Amount (Approved Loan + Interest)
            $total_amount = $approved_loan_amount + ($approved_loan_amount * $interestrate / 100);
            
            $update_query = "UPDATE loanapplication SET approved_loan_amount = ?, interestrate = ?, total_amount = ? WHERE id = ?";
            
            if ($stmt = $conn->prepare($update_query)) {
                $stmt->bind_param("dddi", $approved_loan_amount, $interestrate, $total_amount, $id);
                $stmt->execute();
                $stmt->close();
            }

            echo "<script>alert('Loan details updated successfully!'); window.location.href = 'approvedR_loans.php';</script>";
        }

        $conn->close();
        ?>

        <script>
        function confirmDelete(id) {
            if (confirm("Are you sure you want to delete this loan application?")) {
                window.location.href = "?delete_loan=" + id;
            }
        }
        </script>
    </div>
</body>
</html>
