<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color:rgb(208, 130, 130);
            
        }
        .menu-toggle {
            display: none;
            font-size: 24px;
            cursor: pointer;
            padding: 10px;
            background: #ea2027;
            color: white;
            border: none;
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 1000;
        }
        .sidebar {
            background-color:rgb(104, 57, 58);
            background-image: linear-gradient(315deg, #ea2027 0%, #ee5a24 74%);
            color: #fff;
            width: 250px;
            height: 100vh;
            padding: 30px;
            position: fixed;
            left: -250px;
            transition: left 0.3s ease;
        }
        .sidebar.active {
            left: 0;
        }
        .sidebar h2 {
            margin-top: 40px;
            text-align: center;
            margin-bottom: 40px;
            font-size: 18px;
            padding: 30px 0;
            background: #ea2027;
            color: white;
            border-radius: 5px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin-bottom: 15px;
        }
        .sidebar ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 16px;
            display: flex;
            align-items: center;
            padding: 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .sidebar ul li a i {
            margin-right: 10px;
        }
        .sidebar ul li a:hover {
            background: white;
            color: #ea2027;
        }
        .logout {
            width: 100%;
            padding: 10px;
            background: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
            text-align: center;
        }
        .logout a {
            text-decoration: none;
            color: white;
        }
        .logout:hover {
            background: #e60000;
        }
        
        @media (min-width: 769px) {
            .sidebar {
                left: 0; /* Sidebar is always visible on larger screens */
            }
            .menu-toggle {
                display: none; /* Hide the menu button on larger screens */
            }
        }
        @media (max-width: 768px) {
            .menu-toggle {
                display: block; /* Show menu button on smaller screens */
            }
        }
    </style>
</head>
<body>
    <button class="menu-toggle" onclick="toggleMenu()"><i class="fas fa-bars"></i></button>
    <div class="sidebar" id="sidebar">
        <h2>Wild Life SOS</h2>
        <ul>
  <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
  <li><a href="#"><i class="fas fa-paw"></i> View Animals</a></li>
  <li><a href="#"><i class="fas fa-user-edit"></i> Edit Animal Info</a></li>
  <li><a href="#"><i class="fas fa-file-alt"></i> View Conservation Projects</a></li>
  <li><a href="#"><i class="fas fa-check-circle"></i> Approve/Reject Projects</a></li>
  <li><a href="#"><i class="fas fa-hand-holding-usd"></i> Donations</a></li>
  <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
</ul>
        <button class="logout"><a href="logout.php">LOG OUT</a></button>
    </div>
    <script>
        function toggleMenu() {
            document.getElementById("sidebar").classList.toggle("active");
        }
    </script>
</body>
</html>
