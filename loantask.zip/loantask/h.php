
    <style>
       body {
           padding: 0;
           margin: 0;
          
           width: 100%;
           background-color: rgb(210, 225, 249);
       }

       .headermaindiv {
        width: 100%;
           display: flex;
           flex-direction: row;
           align-content: space-between;
         
           position: sticky; 
    top: 0; 
    z-index: 1000; 
       }

       .headerchild1 {
           border: 2px solid whitesmoke;
           width: 100%;
           display: flex;
           flex-direction: row;
           
           background-color:skyblue;
          
       }

       .headerchild1 img {
           height: 120px;
           width: 100%;
       }

       .headerchild2 {
           margin: 5px;
           padding: 0;
           margin-left: 380px;
           
           width: 50%;
           
           background-color: skyblue;
           color: aliceblue;
           text-align: center;
       }

       .portallogo {
           width: 40%;
           border-top-right-radius: 30px;
       }

       .portallogo img {
           height: 120px;
           width: 160px;
           text-align: center;
           padding-left: 20px;
       }

       .navitems {
           border: 1px solid black;
          
           height: 50px;
           background-color: rgb(1, 1, 107);
           position: sticky; 
    top: 120px; 
    z-index: 1000; 
       }

       .nav-list {
           list-style: none;
           margin: 0;
           padding: 0;
           display: flex;
           justify-content: start;
           align-items: center;
           height: 50px;
           padding-left: 250px;
           gap: 30px;
       }

       .nav-item {
           margin: 10px 10px;
           position: relative; 
       }

       .nav-item a {
           display: inline-block;
           padding: 10px 10px;
           background-color: rgb(0, 0, 128);
           border-radius: 10px;
           color: white;
           text-decoration: none;
           font-size: 16px;
       }

       .nav-item a:hover {
           background-color: rgb(0, 102, 204);
       }

       .dropdown-toggle {
           display: flex;
           align-items: center;
           justify-content: space-between;
           cursor: pointer;
       }

       .dropdown-symbol {
           margin-left: 5px;
           font-size: 14px;
       }

       
       .dropdown-menu {
           display: none;
           position: absolute;
           top: 50px;
           left: 0;
           background-color: rgb(1, 1, 107);
           border-radius: 5px;
           list-style: none;
           margin: 0;
           padding: 0;
           min-width: 130px;
           box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
           z-index: 1000;
       }

       .dropdown-menu li {
           border-bottom: 1px solid white;
       }

       .dropdown-menu li:last-child {
           border-bottom: none;
       }

       .dropdown-menu a {
           color: white;
           text-decoration: none;
           padding: 10px;
           display: block;
       }

       .dropdown-menu a:hover {
           background-color: rgb(0, 102, 204);
       }

       .dropdown-menu.show {
           display: block;
       }
       .avatar{
        height:30px;
        border-radius: 40px;
        width:30px;
        margin-left: 300px;
     
       }

       .nav-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 20px;
      background-color: #333;
      color: white;
    }

    .nav-header .logo {
      font-size: 1.5em;
      font-weight: bold;
    }

    
    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
    }

    .hamburger div {
      width: 25px;
      height: 3px;
      background-color:black !important;
      margin: 4px 0;
    }

    
   
       
       
    </style>
     
</head>
<body>
<div class="headermaindiv">
    
  <div class="headerchild1">
  <div class="hamburger">
      <div></div>
      <div></div>
      <div></div>
     
    </div>
    
    <div class="headerchild2">
   <h2><img src="https://canarabank.com/assets/images/logo.webp"></h2>
    </div>
  
    <div class="portallogo">
      
    </div>
  </div>
</div>



<div class="navitems">

  <ul class="nav-list nav-menu">
    <li class="nav-item"><a href="Homepagem.php">Home</a></li>
    
   
   <li class="nav-item"><a href="financialplanning.php">Financial Planning & Support</a></li>
    <li class="nav-item"><a href="contactus.php">Contact Us</a></li>
    <?php
    if(!isset($_SESSION['full_name'])){
    echo '<li class="nav-item dropdown">
      <a href="#" class="dropdown-toggle">
        Loans <span class="dropdown-symbol">▼</span>
      </a>
<ul class="dropdown-menu">
        <li><a href="usersign.php">Loan Registration</a></li>
        <li><a href="usersign.php">Loan Status</a></li>
      </ul>
    </li>';
}
?>
 <?php
    if(isset($_SESSION['full_name'])){
        $name=$_SESSION['full_name'];
        echo '<li class="nav-item dropdown">
        <a href="#" class="dropdown-toggle">
          Loans <span class="dropdown-symbol">▼</span>
        </a>
  <ul class="dropdown-menu">
          <li><a href="loanregis.php">Loan Registration</a></li>
          <li><a href="loanstatus.php">Loan Status</a></li>
        </ul>
      </li>';
  
    
        }
        ?>

    <?php
    if(!isset($_SESSION['full_name'])){
    echo '<li class="nav-item dropdown">
      <a href="#" class="dropdown-toggle">
        Register/Login <span class="dropdown-symbol">▼</span>
      </a>
<ul class="dropdown-menu">
        <li><a href="userregistration.php">User Registration</a></li>
        <li><a href="usersign.php">User Login</a></li>
      </ul>
    </li>';
}
    ?>
    <?php
    if(isset($_SESSION['full_name'])){
        $name=$_SESSION['full_name'];
            echo '
 
            <li class="nav-item dropdown">
              
      <a href="#" class="dropdown-toggle">
      <span class="ava"><span>
       <span class="dropdown-symbol">' . $name . ' ▼</span>
      </a>
      <ul class="dropdown-menu">
      <li><a href="profileedit.php">Profile Edit</a></li>
        <li><a href="logout.php">logout</a></li>
      
      </ul>
      
    </li>';
  
    
        }
        ?>
        
  </ul>
  
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const dropdownToggles = document.querySelectorAll('.dropdown-toggle');

        dropdownToggles.forEach(toggle => {
            toggle.addEventListener('click', function (event) {
                event.preventDefault();
                const dropdownMenu = this.nextElementSibling;
                dropdownMenu.classList.toggle('show');
            });
        });

        
        document.addEventListener('click', function (event) {
            dropdownToggles.forEach(toggle => {
                const dropdownMenu = toggle.nextElementSibling;
                if (!toggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
                    dropdownMenu.classList.remove('show');
                }
            });
        });
    });
</script>
<script>
    // Hamburger toggle functionality
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger.addEventListener('click', () => {
      navMenu.classList.toggle('active');
    });
  </script>
</body>
</html>
