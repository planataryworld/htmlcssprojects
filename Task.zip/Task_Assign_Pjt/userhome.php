

<?php

session_start();

include 'connection.php';

if (!isset($_SESSION['email'])) {  // If session is not set, it redirects to login page.
    header("Location:index.php");
    exit();
}

$user_Id = $_SESSION['email'];

$sqlQuery = "SELECT * FROM users WHERE email='$user_Id'";
$getResult = mysqli_query($conn, $sqlQuery);

if (!$getResult) {
    echo "<script>alert('Error fetching user data.');</script>";
    exit();
}

$rowData = mysqli_fetch_assoc($getResult);

// Combine firstname and lastname into a full name
$fullName = $rowData['firstname'] . " " . $rowData['lastname'];

// Store the full name in session
$_SESSION['full_name'] = $fullName;

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .mainbody {
            background: #ff4d4d;
            height: 58vh;
        }

        .dashboard-header {
            padding: 20px;
            text-align: left;
        }

        .dashboard-header h1 {
            margin: 0;
            font-size: 28px;
            margin-left: 300px;
        }

        .dashboard-header p {
            margin: 5px 0 20px;
            font-size: 16px;
            color: #ffd5d5;
            margin-left: 300px;
        }

        .classes {
            display: flex;
            flex-direction: row;
            margin-left: 310px;
            margin-top: 20px;
            gap: 90px; 
        }

        .cls1, .cls2, .cls3, .cls4 {
            height: 250px;
            width: 280px;
            border: 1px solid black;
            border-radius: 15px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-color: white;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .cls1:hover, .cls2:hover, .cls3:hover, .cls4:hover {
            transform: scale(1.1); 
            box-shadow: 5px 10px 20px rgba(0, 0, 0, 0.3); 
        }

        .cls1 h3, .cls2 h3, .cls3 h3, .cls4 h3 {
            color: black;
            font-size: 24px;
        }

        .cls1 p, .cls2 p, .cls3 p, .cls4 p {
            font-size: 30px;
            color: black; 
            font-weight: bold;
        }

        .cls1 i, .cls2 i, .cls3 i, .cls4 i {
            font-size: 50px;
            color: #ff4d4d; /* Change this color as needed */
            margin-top: 5px;
        }

        .search-container {
            flex-grow: 0.5;
            display: flex;
            gap: 20px;
        }

        .search-bar {
            width: 300px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
            height: 20px;
            margin-top: 25px;
            margin-left: 150px;
        }

        .search-bar::placeholder {
            color: #aaa;
        }
        .search {
            display: flex;
            justify-content: space-evenly;
        }
        .cancel {
            margin-top: 30px;
        }
    </style>
</head>
<?php 
include 'sidenav2.php'?>
<body>
    <div class="mainbody">
        <div class="search">   
        <div class="dashboard-header">
            <h1>Dashboard</h1>
            <p style="color: yellow; font-size:20px;">Welcome back, 
                
                <?php
                // Display the full name if the user is logged in
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!
            
        </div>
        <div class="search-container">
                <input type="text" class="search-bar" placeholder="Search">&nbsp;&nbsp;&nbsp;
                <span class="cancel">Cancel</span>
                <span class="cancel">select Theme</span>
                <span class="cancel">Default</span>
            </div>
            </div>
        <section>
            <div class="classes">
                <div class="cls1">
                    <h3>Total Tasks</h3>
                    <p>13</p>
                    <i class="fas fa-shopping-bag"></i>
                </div>
                <div class="cls2">
                    <h3>Total Pending Tasks</h3>
                    <p>4</p>
                    <i class="fas fa-layer-group"></i>
                </div>
                <div class="cls3">
                    <h3>Total Completed Tasks</h3>
                    <p>0</p>
                    <i class="fas fa-project-diagram"></i>
                </div>
                <!-- <div class="cls4">
                    <h3>Total Users</h3>
                    <p>359</p>
                    <i class="fas fa-user"></i>
                </div> -->
            </div>
        </section>
    </div>
</body>
</html>
