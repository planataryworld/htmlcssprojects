<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    
    if (empty($email) || empty($password)) {
        echo "<script type='text/javascript'>alert('Please enter both email and password');</script>";
    } else {
        
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $user_data = $result->fetch_assoc();

                
                if (password_verify($password, $user_data['password'])) {
                    
                    $full_name = $user_data['firstname'] . " " . $user_data['lastname'];
                    $_SESSION['full_name'] = $full_name; 
                    $_SESSION['email'] = $user_data['email']; 
                    $_SESSION['id'] = $user_data['id'];
                    header("Location: userhome.php"); 
                    exit();
                } else {
                    echo "<script type='text/javascript'>alert('Wrong password');</script>";
                }
            } else {
                echo "<script type='text/javascript'>alert('User not found');</script>";
            }
        } else {
            echo "<script type='text/javascript'>alert('Database query failed');</script>";
        }
    }
}
?>







<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="styles.css">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
</head>

<style>
    /* General Reset */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Body Styling */
body {
  font-family: Arial, sans-serif;
  background-color: #F04F47; /* Red Background */
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  overflow: hidden;
}

/* Container for Login Card */
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
}

/* Login Card Styling */
.login-card {
  background-color: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
  text-align: center;
  width: 300px;
  height: 450px;
}

/* Welcome Title */
.login-card h2 {
  font-size: 1.8em;
  margin-bottom: 15px;
  color: #333;
}

/* Logo Image */
.logo {
  width: 80px; /* Adjust size accordingly */
  margin-bottom: 20px;
}

/* Input Fields */
input {
  width: 100%;
  padding: 10px;
  margin: 10px 0;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 1em;
  margin-top: 45px;
}

/* Login Button */
.login-button {
  background-color: #F04F47; /* Matching Red */
  color: #fff;
  border: none;
  width: 100%;
  padding: 10px;
  font-size: 1em;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;
  margin-top: 55px;
}

.login-button:hover {
  background-color: #e2443f; /* Slightly darker red */
}

/* Responsive Design for Small Devices */
@media (max-width: 479px) {
  .login-card {
    width: 90%;
    padding: 20px;
  }
}

</style>

<script>
    function validateForm(){

        debugger;

        const admin = document.adminLoginForm;

        const userid = admin.userid.value;
    const useridRegex = /^[a-zA-Z0-9]+$/;
    const testChooseUserid = useridRegex.test(userid);
 
    
     // Password Validation
     const pswd = admin.pswd.value;

     if (userid === "") {
      alert("please enter userid.");
      return false;
    }

    if (/^\s|\s$/.test(userid)) {
  alert("Userid  should not with spaces.");
  return false;
    }

    
    if (pswd === "") {
        alert("Password should not be empty.");
        return false;
    }
    
    if (/^\s|\s$/.test(pswd)) {
        alert("Password should not start with spaces.");
        return false;
    }
    
    
    return true;

    }
                    
</script>

<body>
  <!-- Main Container -->
  <div class="container">
    <div class="login-card">
      <h3>Welcome JMJ Company</h3>
      <!-- Placeholder Image -->
      <!-- <img src="image-placeholder.png" alt="Delivery Scooter" class="logo"> -->
      <!-- Input Fields -->
      <form name="adminLoginForm"  method="post" onsubmit="return validateForm()">
        <input type="email" name="email" placeholder="Email">
        <input type="password" name="password" placeholder="Password">
        <button type="submit" class="login-button" onclick="window.location.href='userhome.php'">LOGIN</button>
        <button type="button" class="login-button" onclick="window.location.href='EmployeeRegis.php'">Register Here</button>
      </form>
    </div>
  </div>
</body>
</html>
