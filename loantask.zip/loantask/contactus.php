<?php
session_start();
?>
<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name'] ?? '');
    $pnumber = trim($_POST['pnumber'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    $sql = "INSERT INTO contactus (name, phonenumber, email, subject, message) 
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $name, $pnumber, $email, $subject, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Query submitted successfully');
        window.location.href='contactus.php'</script>";
    } else {
        echo "<script>alert('An error occurred. Please try again.');</script>";
    }

    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Customer Support</title>
    <link rel="stylesheet" href="style.css">
    <style>
       
        .contact-support {
            width: 60%;
            margin: 50px auto;
            padding: 30px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            font-family: Arial, sans-serif;
        }

        .contact-support h2 {
            text-align: center;
            color: #007BFF;
        }

        .contact-support p {
            font-size: 16px;
            color: #333;
            text-align: center;
        }

        .contact-support .contact-form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .contact-support .form-group {
            width: 100%;
            margin-bottom: 20px;
        }

        .contact-support label {
            font-size: 16px;
            color: #333;
            margin-bottom: 8px;
            display: block;
        }

        .contact-support input, .contact-support textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            margin-top: 5px;
        }

        .contact-support button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }

        .contact-support button:hover {
            background-color: #218838;
        }

        .contact-support .note {
            font-size: 14px;
            color: #888;
            text-align: center;
            margin-top: 15px;
        }
    </style>
</head>
<body>
<?php include 'h.php'; ?>
    <div class="contact-support">
        <h2>Contact Customer Support</h2>
        <p>If you have any questions or issues related to loan approval, payments, or account management, feel free to reach out to us.</p>

    
        <form class="contact-form" method="post" action="contactus.php">
            <div class="form-group">
                <label for="name">Your Name:</label>
                <input type="text" id="name" name="name" placeholder="Enter your name" required>
            </div>

            <div class="form-group">
                <label for="pnumber">Phonenumber:</label>
                <input type="number" id="pnumber" name="pnumber" placeholder="Enter your phonenumber" required>
            </div>
            
            <div class="form-group">
                <label for="email">Your Email:</label>
                <input type="email" id="email" name="email" placeholder="Enter your email address" required>
            </div>
            
            <div class="form-group">
                <label for="subject">Subject:</label>
                <input type="text" id="subject" name="subject" placeholder="Enter the subject of your query" required>
            </div>
            
            <div class="form-group">
                <label for="message">Your Message:</label>
                <textarea id="message" name="message" placeholder="Write your message here..." rows="5" required></textarea>
            </div>

            <button type="submit">Submit Query</button>
        </form>

        <div class="note">
            <p>We aim to respond to your query within 24 hours. Thank you for contacting us!</p>
        </div>
    </div>

</body>
</html>