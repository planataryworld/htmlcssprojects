<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jobportal-HomePage</title>
    <link rel="stylesheet" href="financial.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        .loan-calculator {
            height:100vh;
            width: 50%;
            margin: 20px auto;
            padding: 20px;
            border: 2px solid #007BFF;
            border-radius: 10px;
            background: #f9f9f9;
            box-shadow: 0px 0px 10px rgba(0, 123, 255, 0.3);
            font-family: Arial, sans-serif;
        }

        .loan-calculator h2 {
            text-align: center;
            color: #007BFF;
        }

        .slider-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 10px 0;
        }

        .slider-container input {
            width: 60px;
            text-align: center;
            border: 1px solid #ccc;
            padding: 5px;
            border-radius: 5px;
        }

        .slider-container input[type="range"] {
            width: 70%;
        }

        .result-box {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }

        .result {
            display: flex !important;
            width: 45%;
            background: #dff6ff;
            padding: 15px;
            margin: 5px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
        }

        .result span {
            display: block;
            font-size: 22px;
            font-weight: bold;
            padding: 5px;
            border-radius: 5px;
            margin-top: 5px;
        }

        .emi span { background: #2da756; color: white; }
        .interest span { background: #fbc02d; color: black; }
        .payable span, .interest-percent span { background: #03a9f4; color: white; }

       
        .container {
           
            width: 60%;
            margin: 50px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #2a9df4;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            font-size: 16px;
            color: #333;
        }

        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .submit-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .submit-btn:hover {
            background-color:rgb(209, 231, 214);
        }

        .result {
          width: 95%;
            margin-top: 30px;
            display: none;
            background-color:rgb(140, 193, 140);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #28a745;
        }

        p {
            font-size: 16px;
            color: #333;
        }
    </style>
</head>
<body>
    <script src="validations.js"></script>
    <div> 
        <?php include 'h.php'; ?>

        <section class="mainbody">
            <section class="mainbody1">    
                <h2><u>Financial Planning</u></h2>
                <div class="bodypart1">
                    <p>Financial planning for banks revolves around ensuring liquidity, managing risks, and maximizing profitability while maintaining regulatory compliance.</p>
                </div>

               
                <div class="loan-calculator">
                    <h2>Loan EMI Calculator</h2>

                   
                    <div class="slider-container">
                        <label>Loan Amount:</label>
                        <input type="number" id="loanAmount" value="50000" min="50000">
                        <input type="range" id="loanRange" min="50000" max="1000000" value="50000" step="1000">
                    </div>

                    
                    <div class="slider-container">
                        <label>Interest Rate (%):</label>
                        <input type="number" id="interestRate" value="7" min="7">
                        <input type="range" id="interestRange" min="1" max="20" value="6" step="0.1">
                    </div>

                    
                    <div class="slider-container">
                        <label>Loan Term (in months):</label>
                        <input type="number" id="loanTerm" value="6" min="1">
                        <input type="range" id="termRange" min="1" max="60" value="6" step="1">
                    </div>

                    
                    <div class="result-box">
                        <div class="result emi">
                            Monthly EMI
                            <span id="emiAmount">₹0.00</span>
                        </div>
                        <div class="result interest">
                            Total Interest
                            <span id="totalInterest">₹0.00</span>
                        </div>
                        <div class="result payable">
                            Payable Amount
                            <span id="payableAmount">₹0.00</span>
                        </div>
                        <!-- <div class="result interest-percent">
                            Interest Percentage
                            <span id="interestPercentage">0.00%</span>
                        </div> -->
                    </div>
                </div>

               
                <div class="container">
                    <h1>Personalized Financial Tips & Loan Recommendations for Your Farm</h1>

                    <form id="financialForm">
                        <div class="form-group">
                            <label for="farmIncome">Annual Farm Income (₹):</label>
                            <input type="number" id="farmIncome" name="farmIncome" required>
                        </div>

                        <div class="form-group">
                            <label for="loanAmount">Current Loan Amount (₹):</label>
                            <input type="number" id="loanAmount" name="loanAmount" required>
                        </div>

                        <div class="form-group">
                            <label for="farmSize">Farm Size (acres):</label>
                            <input type="number" id="farmSize" name="farmSize" required>
                        </div>

                        <div class="form-group">
                            <label for="expenses">Annual Expenses (₹):</label>
                            <input type="number" id="expenses" name="expenses" required>
                        </div>

                        <button type="submit" class="submit-btn">Get Recommendations</button>
                    </form>

                    <div id="financialTips" class="result">
                        <h2>Your Personalized Recommendations</h2>
                        <p id="loanRecommendation">Loan Recommendation: </p>
                        <p id="financialTip">Financial Tip: </p>
                    </div>
                </div>

            </section>
        </section>
    </div>

    <script>
        
        function calculateEMI() {
            let principal = parseFloat(document.getElementById("loanAmount").value);
            let annualRate = parseFloat(document.getElementById("interestRate").value);
            let months = parseInt(document.getElementById("loanTerm").value);

            let monthlyRate = annualRate / 12 / 100;
            let emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);

            let totalPayment = emi * months;
            let totalInterest = totalPayment - principal;
            let interestPercentage = (totalInterest / principal) * 100;

            document.getElementById("emiAmount").innerText = `₹${emi.toFixed(2)}`;
            document.getElementById("totalInterest").innerText = `₹${totalInterest.toFixed(2)}`;
            document.getElementById("payableAmount").innerText = `₹${totalPayment.toFixed(2)}`;
            document.getElementById("interestPercentage").innerText = `${interestPercentage.toFixed(2)} %`;
        }

        
        function syncValues() {
            document.getElementById("loanRange").value = document.getElementById("loanAmount").value;
            document.getElementById("interestRange").value = document.getElementById("interestRate").value;
            document.getElementById("termRange").value = document.getElementById("loanTerm").value;
            calculateEMI();
        }

        
        document.getElementById("loanAmount").addEventListener("input", syncValues);
        document.getElementById("loanRange").addEventListener("input", function() {
            document.getElementById("loanAmount").value = this.value;
            calculateEMI();
        });

        document.getElementById("interestRate").addEventListener("input", syncValues);
        document.getElementById("interestRange").addEventListener("input", function() {
            document.getElementById("interestRate").value = this.value;
            calculateEMI();
        });

        document.getElementById("loanTerm").addEventListener("input", syncValues);
        document.getElementById("termRange").addEventListener("input", function() {
            document.getElementById("loanTerm").value = this.value;
            calculateEMI();
        });

        
        calculateEMI();

        
        document.getElementById("financialForm").addEventListener("submit", function(event) {
            event.preventDefault();

            var income = document.getElementById("farmIncome").value;
            var loanAmount = document.getElementById("loanAmount").value;
            var farmSize = document.getElementById("farmSize").value;
            var expenses = document.getElementById("expenses").value;

            
            var loanRecommendation = `Based on your annual farm income of ₹${income}, it is recommended to consider a loan amount of ₹${loanAmount}.`;
            var financialTip = `Ensure that your farm expenses do not exceed 50% of your annual income (₹${expenses}). Aim for a savings target of 20%.`;

            document.getElementById("loanRecommendation").textContent = loanRecommendation;
            document.getElementById("financialTip").textContent = financialTip;
            document.getElementById("financialTips").style.display = "block";
        });
    </script>

</body>
</html>
