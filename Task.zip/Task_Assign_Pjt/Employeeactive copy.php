<?php 
include 'connection.php';
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            box-sizing: border-box;
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: rgb(192, 187, 187); 
        }

        .container {
            padding: 20px;
        }

        .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 300px;
        }

        .toolbar {
            display: flex;
            width: 47%;
            justify-content: end;
            align-items: flex-end;
            flex-direction: row;
            gap: 45px;
            padding: 10px;
            background-color: rgb(192, 187, 187);
            border-radius: 8px;
            margin-top: 20px;
            margin-left: 780px;
        }

        .sort {
            display: flex;
            align-items: center;
            color: #333;
            cursor: pointer;
           
            margin-bottom: 11px;
        }

        .filter-icon {
            font-size: 16px;
            margin-right: 4px;
        }

        .search-container {
            flex-grow: 1;
            display: flex;
        }

        .search-bar {
            width: 250px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
        }

        .search-bar::placeholder {
            color: #aaa;
        }

        .cancel {
            color: #e74c3c;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
            padding: 8px;
        }

        .add-product {
            background-color: #e74c3c;
            color: #fff;
            border: none;
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            width: 15vw;
            height: 5vh;
        }

        .add-product:hover {
            background-color: #c0392b;
        }

        .header {
            background-color: #E74C3C;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }

        .add-product-btn {
            margin: 20px;
            background-color: #E74C3C;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .add-product-btn:hover {
            opacity: 0.8;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #c0392b; /* Adjusted background color for better contrast */
            color: white;
            padding: 10px 20px;
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .close-btn {
            color: white;
            font-size: 24px;
            cursor: pointer;
        }

        .form-row {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column; /* Stacked label and input */
        }

        .form-row label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        .input-container {
            display: flex;
            align-items: center;
        }

        .input-container i {
            margin-right: 10px;
            font-size: 18px;
            color: #2980B9;
        }

        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #CCC;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: none;
        }

        .button-container {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn-cancel {
            background-color: #E74C3C;
        }

        .btn-save {
            background-color: #2980B9;
        }

        .btn:hover {
            opacity: 0.8;
        }

         /* Container for the table */
.student-database-container {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    margin: 20px auto;
    width: 75%;
    background-color: #f9f9f9;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    padding: 10px;
    margin-left: 340px;
}

/* Header for the table */
.student-database-container h3 {
    color: #5B3D7F;
    text-align: center;
    font-size: 22px;
    margin-bottom: 10px;
}

/* Table styles */
.student-database-container table {
    width: 100%;
    border-collapse: collapse;
    background-color: #ffffff;
}

.student-database-container th {
    text-align: left;
    font-weight: bold;
    color: #ff5252; /* Red header color */
    padding: 10px;
    border-bottom: 2px solid #e0e0e0;
    font-size: 16px;
    text-transform: lowercase;
}

.student-database-container td {
    color: #333;
    padding: 10px;
    border-bottom: 1px solid #e0e0e0;
    font-size: 14px;
    text-align: left;
}

.student-database-container tr:nth-child(even) {
    background-color: #f5f5f5; /* Alternate row background */
}

.student-database-container tr:last-child td {
    border-bottom: none; /* Remove bottom border for last row */
}

.student-database-container td[colspan="5"] {
    text-align: center;
    font-weight: bold;
    color: #ff5252;
}

    </style>
    
    <?php 
include 'sidenav2.php'?>
</head>
<body>
<script src="adminproductmain.js"></script>
    <div class="container">
        <div class="description">
            
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
                // Display the full name if the user is logged in
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
               
        </div>

        <!-- <div class="toolbar">
            <div class="sort">
                <i class="fa-solid fa-filter"></i>&nbsp;&nbsp;
                <span>Sort</span>
            </div>

            <div class="search-container">
                <input type="text" class="search-bar" placeholder="Search">&nbsp;&nbsp;&nbsp;
                <span class="cancel">Cancel</span>
            </div>

            <button class="add-product" id="openModalBtn">+ Add New Services</button>
        </div> -->
    </div>

    

     

    <div class="student-database-container">
    <h3>InProgressTickets Info</h3>
    <table>
         <tbody>

        <?php
       include 'connection.php';

       
       $query = "SELECT t.id, t.title, t.description, t.priority, t.status, t.created_at, CONCAT(u.firstname, ' ', u.lastname) AS assigned_to
         FROM tickets t
         LEFT JOIN users u ON t.assigned_to = u.id
         WHERE t.status = 'open'";

  
       $result = $conn->query($query);

      
       if ($result && $result->num_rows > 0) {
        
           echo "<table border='1'>
                   <tr>
                       <th>Ticket ID</th>
                       <th>Title</th>
                       <th>Description</th>
                       <th>Priority</th>
                       <th>Status</th>
                       <th>Created At</th>
                       <th>Assigned To</th>
                   </tr>";

          
           while ($row = $result->fetch_assoc()) {
               echo "<tr>
                       <td>" . $row['id'] . "</td>
                       <td>" . htmlspecialchars($row['title']) . "</td>
                       <td>" . htmlspecialchars($row['description']) . "</td>
                       <td>" . ucfirst($row['priority']) . "</td>
                       <td>" . ucfirst($row['status']) . "</td>
                       <td>" . $row['created_at'] . "</td>
                       <td>" . ($row['assigned_to'] ? htmlspecialchars($row['assigned_to']) : 'Not Assigned') . "</td>
                   </tr>";
           }
           echo "</table>";
       } else {
           echo "<div class='student-database-container'><h3>No tickets found</h3></div>";
       }

       // Close the database connection
       $conn->close();
       ?>

            </tbody>
    </table>
</div>






    <script>
        const modal = document.getElementById("productModal");
        const openModalBtn = document.getElementById("openModalBtn");
        const closeModalBtns = document.querySelectorAll("#closeModalBtn, #closeModalBtn2");

        openModalBtn.addEventListener("click", () => {
            modal.style.display = "flex";
        });

        closeModalBtns.forEach(btn => {
            btn.addEventListener("click", () => {
                modal.style.display = "none";
            });
        });
    </script>
</body>
</html>
