<?php
session_start();

include 'connection.php';

if (!isset($_SESSION['email'])) { 
    header("Location:index.php");
    exit();
}

$user_Id = $_SESSION['email'];

$sqlQuery = "SELECT * FROM admin WHERE email='$user_Id'";
$getResult = mysqli_query($conn, $sqlQuery);

if (!$getResult) {
    echo "<script>alert('Error fetching user data.');</script>";
    exit();
}

$rowData = mysqli_fetch_assoc($getResult);


$query = "SELECT COUNT(*) as total_tasks FROM tickets";
$result = $conn->query($query);
$total_tasks = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_tasks = $row['total_tasks'];
}

$query = "SELECT COUNT(*) as total_users FROM users";
$result = $conn->query($query);
$total_users = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_users = $row['total_users'];
}


$query = "SELECT COUNT(*) as total_in_progress FROM tickets WHERE status = 'in_progress'";
$result = $conn->query($query);
$total_in_progress = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_in_progress = $row['total_in_progress'];
}

$query = "SELECT COUNT(*) as total_resolved FROM tickets WHERE status = 'resolved'";
$result = $conn->query($query);
$total_resolved = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_resolved = $row['total_resolved'];
}

$query = "SELECT COUNT(*) as total_active FROM tickets WHERE status = 'open'";
$result = $conn->query($query);
$total_active = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_active = $row['total_active'];
}

$query = "SELECT COUNT(*) as total_overdue FROM tickets WHERE status = ''";
$result = $conn->query($query);
$total_overdue = 0;
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_overdue = $row['total_overdue'];
}
$conn->close();
?>


 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .mainbody {
            background: #ff4d4d;
            height: 100vh;
        }

        .dashboard-header {
            padding: 20px;
            text-align: left;
        }

        .dashboard-header h1 {
            margin: 0;
            font-size: 28px;
            margin-left: 300px;
        }

        .dashboard-header p {
            margin: 5px 0 20px;
            font-size: 16px;
            color: #ffd5d5;
            margin-left: 300px;
        }

        .classes {
    display: grid;
    grid-template-columns: repeat(2, 1fr); 
    gap: 5px; 
    justify-content: space-between;  
}

.cls1, .cls2, .cls3, .cls4, .cls5, .cls6 {
    box-sizing: border-box;
    height: 200px;  
    width: 50%; 
    padding: 5px;  
    border: 1px solid #ddd;  
    border-radius: 10px;  
    background-color: #f9f9f9;  
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    margin-left: 350px;
}

.cls1:hover, .cls2:hover, .cls3:hover, .cls4:hover, .cls5:hover, .cls6:hover {
    transform: scale(1.1); 
    box-shadow: 5px 10px 20px rgba(0, 0, 0, 0.3); 
}

.cls1 h3, .cls2 h3, .cls3 h3, .cls4 h3, .cls5 h3, .cls6 h3 {
    color: black;
    font-size: 24px;
}

.cls1 p, .cls2 p, .cls3 p, .cls4 p, .cls5 p, .cls6 p {
    font-size: 30px;
    color: black; 
    font-weight: bold;
}

.cls1 i, .cls2 i, .cls3 i, .cls4 i, .cls5 i, .cls6 i {
    font-size: 30px;  
    color: #ff4d4d; 
}
        .search-container {
            flex-grow: 0.5;
            display: flex;
            gap: 20px;
        }

        .search-bar {
            width: 300px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 14px;
            background-color: #f2f2f2;
            height: 20px;
            margin-top: 25px;
            margin-left: 150px;
        }

        .search-bar::placeholder {
            color: #aaa;
        }
        .search {
            display: flex;
            justify-content: space-evenly;
        }
        .cancel {
            margin-top: 30px;
        }
    </style>
</head>
<?php 
include 'sidenav2.php'?>
<body>
    <div class="mainbody">
        <div class="search">   
        <div class="dashboard-header">
            <h1>Dashboard</h1>
            <p style="color: yellow; font-size:20px;">Welcome back, 
                
                <?php
                
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!
            
        </div>
        <div class="search-container">
                <input type="text" class="search-bar" placeholder="Search">&nbsp;&nbsp;&nbsp;
                <span class="cancel">Cancel</span>
                <span class="cancel">select Theme</span>
                <span class="cancel">Default</span>
            </div>
            </div>
        <section>
        <div class="classes">
   
   
    
<div class="cls1">
    <h3>Total Tasks</h3>
    <p><?php echo $total_tasks; ?></p>  
    <i class="fas fa-tasks"></i>
</div>
   
    
    
    <div class="cls2">
        <h3>Total Pending Tasks</h3>
        <p><?php echo $total_in_progress ?></p>  
        <i class="fas fa-exclamation-circle"></i>
    </div>
    
    
    <div class="cls3">
        <h3>Total Completed Tasks</h3>
        <p><?php echo $total_resolved ?></p>  
        <i class="fas fa-check-circle"></i>
    </div>
    
  
    <div class="cls4">
        <h3>Active Tasks</h3>
        <p><?php echo $total_active ?></P> 
        <i class="fas fa-play-circle"></i>
    </div>
    
    <div class="cls5">
        <h3>Total Users</h3>
        <p><?php echo $total_users; ?></p>  
        <i class="fas fa-users"></i>
    </div>
    
   
    <div class="cls6">
        <h3>Overdue Tasks</h3>
        <p><?php echo $total_overdue ?></p>
        <i class="fas fa-clock"></i>
    </div>
</div>

        </section>
    </div>
</body>
</html>
