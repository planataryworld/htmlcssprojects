<?php 
include 'connection.php';
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css" integrity="sha512-5Hs3dF2AEPkpNAR7UiOHba+lRSJNeM2ECkwxUIxC1Q/FLycGTbNapWXB4tP889k5T5Ju8fs4b1P5z/iB4nMfSQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
      body {
        box-sizing: border-box;
        margin: 0;
        font-family: Arial, sans-serif;
        background: #ff4d4d;
        overflow-x: hidden; 
      }

      .description {
            flex: 1;
        }

        .description p {
            font-size: 18px;
            color: #555;
            margin: 0;
            margin-left: 900px;
          
        }
      .container {
        margin-left: 250px;
        padding: 20px;
        width: 100%;
      }

      .student-database-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        padding: 20px;
        background-color: #fff;
        width: 80%; 
        max-width: 1200px; 
        margin: 20px auto; 
        box-shadow: none;
        border-radius: 10px;
        margin-left: 300px;
        box-sizing: border-box; 
      }

      .student-database-container h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
      }

     
      table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        border-radius: 10px;
        overflow: hidden;
      }

     
      table, th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
      }

      
      th {
        background-color: #f2f2f2;
        color: #333;
        font-weight: bold;
      }

     
      tr:nth-child(even) {
        background-color: #f9f9f9;
      }

      tr:hover {
        background-color: #f1f1f1;
      }

      
      td {
        font-size: 14px;
        color: #333;
      }

      .student-database-container table {
        margin: 0 auto;
        width: 100%;
      }
    </style>

    <?php 
    include 'sidenav2.php'; 
    ?>
</head>
<body>

    <div class="container">
        <div class="description">
            <p style="color: yellow; font-size:20px;">Welcome back, <?php
               
                if (isset($_SESSION['full_name'])) {
                    echo "<span class='username'> " . htmlspecialchars($_SESSION['full_name']) . "</span>";
                }
            ?>!</p>
        </div>
    </div>

    <div class="student-database-container">
    <h3>Contact Support Tickets</h3>
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Search tickets..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
        <button type="submit">Search</button>
    </form>
    <?php
include 'connection.php';

$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

$query = "SELECT id, name, phonenumber, email, subject, message, status FROM contactus";

if ($search) {
    $query .= " WHERE name LIKE '%$search%' OR phonenumber LIKE '%$search%' OR email LIKE '%$search%' OR subject LIKE '%$search%' OR message LIKE '%$search%'";
}

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['id'] . "</td>
                <td>" . htmlspecialchars($row['name']) . "</td>
                <td>" . htmlspecialchars($row['phonenumber']) . "</td>
                <td>" . htmlspecialchars($row['email']) . "</td>
                <td>" . htmlspecialchars($row['subject']) . "</td>
                <td>" . htmlspecialchars($row['message']) . "</td>
                <td>" . htmlspecialchars($row['status']) . "</td>
                <td>
                    <a href='editcontact.php?id=" . $row['id'] . "'>Edit</a> | 
                    <a href='?delete_contact=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this contact?\")'>Delete</a> | 
                    <a href='?update_status=" . $row['id'] . "&status=resolved'>Resolved</a> | 
                    <a href='?update_status=" . $row['id'] . "&status=inprogress'>In Progress</a>
                </td>
            </tr>";
    }
    echo "</table>";
} else {
    echo "<div class='ticket-database-container'><h3>No contacts found</h3></div>";
}

if (isset($_GET['delete_contact'])) {
    $contact_id = intval($_GET['delete_contact']);

    $delete_query = "DELETE FROM contactus WHERE id = ?";
    if ($stmt = $conn->prepare($delete_query)) {
        $stmt->bind_param("i", $contact_id);
        if ($stmt->execute()) {
            echo "<script>
                    alert('Contact deleted successfully!');
                    window.location.href = 'supporttickets.php';  // Reload the page to reflect the change
                  </script>";
        } else {
            echo "<script>alert('Error deleting contact.'); window.history.back();</script>";
        }
        $stmt->close();
    }
}

if (isset($_GET['update_status'])) {
    $contact_id = intval($_GET['update_status']);
    $status = $_GET['status'];

    $update_query = "UPDATE contactus SET status = ? WHERE id = ?";
    if ($stmt = $conn->prepare($update_query)) {
        $stmt->bind_param("si", $status, $contact_id);
        if ($stmt->execute()) {
            echo "<script>
                    alert('Status updated successfully!');
                    window.location.href = 'supporttickets.php';  // Reload the page to reflect the change
                  </script>";
        } else {
            echo "<script>alert('Error updating status.'); window.history.back();</script>";
        }
        $stmt->close();
    }
}

$conn->close();
?>
</div>
</body>
</html>