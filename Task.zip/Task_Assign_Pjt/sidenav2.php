<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grocery Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            color: #fff;
        }

        .sidebar {
            /* background:rgb(170, 61, 78); */
            background-color: #ea2027;
background-image: linear-gradient(315deg, #ea2027 0%, #ee5a24 74%);

            color: #fff;
            width: 250px;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .sidebar h2 {
            margin: 0;
            text-align: center;
            margin-bottom: 40px;
            font-size: 18px;
           
            padding: 10px 0; /* Add some padding for better visual spacing */
            background-color: #ea2027;
            background-image: linear-gradient(315deg, #ea2027 0%, #ee5a24 74%);
               box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2); /* Box shadow with slight opacity */
              border-radius: 5px; /* Optional: Add rounded corners */
               color: white; /* Text color for better contrast */
            height: 5vh;
               justify-content: center;
               align-items: center;
              display: flex;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
           
            background-color: #ea2027;
            background-image: linear-gradient(315deg, #ea2027 0%, #ee5a24 74%);
           box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2); /* Box shadow with slight opacity */
             border-radius: 5px; /* Optional: Add rounded corners */
             color: white; /* Text color for better contrast */
    
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            display: flex;
            align-items: center;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar ul li a i {
            margin-right: 10px;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background: white;
            color: #ea2027;
        }

        .logout {
            margin-top: 120px;
            width: 100%;
            padding: 10px;
            background: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-transform: uppercase;
            font-size: 16px;
            transition: background 0.3s;
           
        }
        .logout a {
            text-decoration: none;
            color:white ;
        }

        .logout:hover {
            background: #e60000;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>JMJ Company Dashboard</h2>
        <ul>
        <li><a href="http://localhost/TASK_ASSIGN_PJT/userhome.php"><i class="fas fa-home">&nbsp;&nbsp;&nbsp;&nbsp;</i> Home</a></li>
            <li><a href="http://localhost/TASK_ASSIGN_PJT/employeeTickets.php"><i class="fa-solid fa-ticket">&nbsp;&nbsp;&nbsp;&nbsp;</i> Open Tickets</a></li>
            <li><a href="http://localhost/TASK_ASSIGN_PJT/completedTickets.php"><i class="fa-solid fa-check">&nbsp;&nbsp;&nbsp;&nbsp;</i> Resolved Tickets</a></li>
            <li><a href="http://localhost/TASK_ASSIGN_PJT/Employeeactive.php"><i class="fa-solid fa-clipboard-check">&nbsp;&nbsp;&nbsp;&nbsp;</i>Tickets</a></li>
            <li><a href="http://localhost/TASK_ASSIGN_PJT/Employeeinprogress.php"><i class="fas fa-tag">&nbsp;&nbsp;&nbsp;&nbsp;</i> InProgress Tickets</a></li>
        </ul>
        <button class="logout"><a href="logout.php">LOG OUT</a> </button>
    </div>
</body>
</html>
